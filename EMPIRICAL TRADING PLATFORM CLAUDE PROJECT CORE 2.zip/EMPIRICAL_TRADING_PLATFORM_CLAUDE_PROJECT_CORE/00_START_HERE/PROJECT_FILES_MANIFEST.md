# Claude Project Core Package — Files Manifest

## Document Control

| Field | Value |
| --- | --- |
| Document name | PROJECT_FILES_MANIFEST.md |
| Purpose | Explain every file retained in `EMPIRICAL_TRADING_PLATFORM_CLAUDE_PROJECT_CORE.zip`, and explain what was deliberately excluded and why. |
| Generation date | 2026-07-23 |
| Mission type | Project Files packaging and consolidation only — no repository modification, no Git verification, no tests, no redesign, no M020 review performed. |

---

## Retained Files

### 01_MASTER_CONTEXT/

| Filename | Category | Purpose | Authority level | Current relevance | Original or consolidated | Why it must remain |
| --- | --- | --- | --- | --- | --- | --- |
| `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` | Consolidated navigation document | Explains what has been built, what is frozen, where the project stands, and what the current mission is. | **Navigation aid only** — not authoritative for technical decisions; frozen milestone documents and verified Git history remain authoritative. | Directly required for every future session's orientation. | **Consolidated** (previously generated in this Claude Project, copied here unmodified). | Without it, a new session has no fast way to reconstruct 20 milestones of decision history. |
| `PROJECT_OPERATING_MANUAL.md` | Consolidated process document | Explains how work must be performed: lifecycle, roles, stop conditions, baseline discipline, validation standard, external review package standard, etc. | **Process guidance only** — frozen milestone documents remain authoritative for technical decisions; this document only governs process. | Directly required so any future agent (Claude Code, ChatGPT, or another Claude session) follows the same discipline. | **Consolidated** (previously generated in this Claude Project, copied here unmodified). | Without it, process discipline (independent review, correction-pass separation, stop conditions) would have to be re-derived or re-explained every session. |

### 02_PROJECT_FOUNDATION/

| Filename | Category | Purpose | Authority level | Current relevance | Original or consolidated | Why it must remain |
| --- | --- | --- | --- | --- | --- | --- |
| `README.md` | Repository foundation document | States the platform's scope and explicit non-implementation boundary list. | Original, low-level authoritative reference. | Establishes the product boundary baseline every other document assumes. | **Original**, copied exactly. | Short, foundational, and directly referenced by the Master Context's "Platform Purpose" section. |
| `pyproject.toml` | Repository configuration | Python version constraint, dependency groups, tool configuration (ruff, mypy, pytest, coverage). | Original, authoritative for toolchain/validation expectations. | Directly referenced by the Operating Manual's Validation Standard (Section 16) — e.g., Python `>=3.13,<3.14`, coverage `fail_under = 80`. | **Original**, copied exactly. | Needed so any future mission can state exact validation expectations without guessing tool versions/thresholds. |

### 03_FROZEN_ARCHITECTURE/

| Filename | Category | Purpose | Authority level | Current relevance | Original or consolidated | Why it must remain |
| --- | --- | --- | --- | --- | --- | --- |
| `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_DESIGN.md` | Frozen design (APPROVED AND FROZEN) | Defines the four initial aggregate roots (Campaign, Run, EvidencePackage, Review), their lifecycle states, identifier model, and entity relationships. | **Original, frozen technical authority.** | M020's repository/concurrency contract design directly depends on this document's identity, lifecycle, and aggregate-boundary decisions. | **Original**, copied exactly. | The project owner explicitly requested this be retained in full so Claude does not rely on summary alone for identity/aggregate decisions. |
| `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_DECISION.md` | Frozen architecture-boundary decision (APPROVED AND FROZEN) | Resolves the package/dependency-direction boundary for Run vs. Campaign vs. Dataset Manifest (`campaign -> datasets` forbidden). | **Original, frozen technical authority.** | Directly relevant to any future architecture-checker question M020 implementation may raise. | **Original**, copied exactly. | The project owner explicitly requested this be retained in full for the same reason as M012. |

### 04_RECONSTRUCTION_M019/

| Filename | Category | Purpose | Authority level | Current relevance | Original or consolidated | Why it must remain |
| --- | --- | --- | --- | --- | --- | --- |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_SCOPE_SELECTION.md` | Frozen scope selection | Selected reconstruction-contract design as the milestone following M018. | Original, frozen. | Establishes the M019 baseline chain M020 depends on. | **Original**, copied exactly. | Needed to trace the exact baseline lineage leading into M020. |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_DESIGN.md` | Frozen design (APPROVED AND FROZEN) | Documentation-level `*ReconstructionState` records, `ReconstructionError`/`ReconstructionErrorCategory`, validation/trust rules for all four aggregates. | Original, frozen. | M020's "Reconstruction Integration" section directly builds on this design. | **Original**, copied exactly. | This is the immediately-prior frozen milestone that M020 must remain compatible with. |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION_SCOPE_SELECTION.md` | Implementation scope selection | Fixed exact module/factory names (`_reconstruction`, `_reconstruct_*`, `object.__new__`). | Original. | Explains the exact internal names M020's repository contracts must not expose publicly. | **Original**, copied exactly. | Needed so a future mission does not accidentally re-invent or contradict already-fixed internal naming. |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md` | Implementation report | Reports the actual reconstruction implementation: files changed, shared error model, shared helper boundary. | Original. | Ground truth for what reconstruction code actually exists today. | **Original**, copied exactly. | Directly relevant evidence for any M020 correction that touches reconstruction integration. |

### 05_ACTIVE_MILESTONE_M020/

| Filename | Category | Purpose | Authority level | Current relevance | Original or consolidated | Why it must remain |
| --- | --- | --- | --- | --- | --- | --- |
| `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` | Active scope selection (SCOPE CANDIDATE SELECTED) | Enumerates the exact repository/concurrency design questions M020 must answer, for all four aggregates. | Original, active (not yet frozen). | This **is** the currently active mission's scope authority. | **Original**, copied exactly. | This is the document the current mission (M020 independent design review) is directly performed against. |
| `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` | Active design (DESIGN READY FOR INDEPENDENT REVIEW — NOT FROZEN) | The actual M020 repository/concurrency contract design: `get`/`add`/`save`, error taxonomy, `SaveResult`, version vocabulary, hostile self-review. | Original, active (not yet frozen). | This is the exact document the next mission (independent review) must be performed against. | **Original**, copied exactly. | This is the single most important document for the current checkpoint — it is what must be independently reviewed next. |

**Total retained files: 12** (2 consolidated + 10 original).

---

## Deliberately Excluded Categories

| Excluded category | Examples | Reason for exclusion |
| --- | --- | --- |
| Superseded historical milestones | `MILESTONE_001_006_DOCUMENT_INTEGRATION_REVIEW.md`, `MILESTONE_004_...` through `MILESTONE_011_...`, `MILESTONE_013_...` through `MILESTONE_015_...`, `MILESTONE_017_...`, `MILESTONE_018_...`, and M012's independent-review/authority-correction/external-reconciliation companion documents | Their conclusions are already carried forward and summarized in `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` (Milestone Lineage, Frozen Domain Primitives, Frozen Aggregate Inventory sections). They remain the ultimate authority for their own content, but are not needed in the *reduced, active* Claude Project file set to continue M020. |
| Intermediate implementation reports not directly required by M020 | M013 (Domain Primitive Foundation), M014 (Evidence Package), M015 (Review), M017 (Run), M018 (Campaign) aggregate-behavior implementation reports | These describe aggregate behavior that M020's repository contracts consume only through the interfaces already summarized in the Master Context and through M012/M016/M019, which are retained in full. |
| Repository configuration files not necessary for conversational context | `_editorconfig`, `_gitignore`, `_dockerignore`, `alembic.ini` | Pure toolchain/formatting configuration with no milestone-narrative content relevant to continuing M020 in a chat environment. |
| Source code and tests | Everything under `src/`, `tests/`, `tools/` | The **real repository remains authoritative** for all source code and tests. A chat/phone environment must never substitute a packaged copy of source for direct repository access. |
| External-review ZIP contents | Any `external-review/<mission>/` packages | Not yet created for M020 (no independent review has occurred yet); would belong in the repository's own evidence trail once produced, not in this Claude Project file set. |
| Chat transcripts | This conversation and prior conversations in this Claude Project | Chat history is not a source document and must not be packaged as if it were project evidence. |

**Excluded files are not deleted from the real repository. They are excluded only from the reduced Claude Project Files set.** The authoritative repository at `C:\Users\LuxSy\Documents\trading` retains every historical milestone document, all source code, and all tests regardless of what is active in this Claude Project.

---

## Note on This Manifest's Own Status

This manifest itself is a **newly created** document (not an original milestone document and not a copy of a previously-consolidated one). It was produced solely to explain the packaging decision above; it makes no technical claims about the platform and defers entirely to the retained original and consolidated documents for that content.
