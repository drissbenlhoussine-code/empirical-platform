# Upload Instructions — Empirical Trading Platform Claude Project Core Package

Follow these steps **in order**. Do not skip the verification steps before deleting anything.

1. **Download and open the ZIP before deleting anything.**
   Download `EMPIRICAL_TRADING_PLATFORM_CLAUDE_PROJECT_CORE.zip` and extract it (on phone or computer). Do not touch the current Claude Project Files yet.

2. **Verify all listed files exist and are non-empty.**
   Confirm the extracted folder contains exactly these 12 core files (plus this instructions folder), matching `PROJECT_FILES_MANIFEST.md`:
   - `01_MASTER_CONTEXT/EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`
   - `01_MASTER_CONTEXT/PROJECT_OPERATING_MANUAL.md`
   - `02_PROJECT_FOUNDATION/README.md`
   - `02_PROJECT_FOUNDATION/pyproject.toml`
   - `03_FROZEN_ARCHITECTURE/MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_DESIGN.md`
   - `03_FROZEN_ARCHITECTURE/MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_DECISION.md`
   - `04_RECONSTRUCTION_M019/MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_SCOPE_SELECTION.md`
   - `04_RECONSTRUCTION_M019/MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_DESIGN.md`
   - `04_RECONSTRUCTION_M019/MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION_SCOPE_SELECTION.md`
   - `04_RECONSTRUCTION_M019/MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md`
   - `05_ACTIVE_MILESTONE_M020/MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md`
   - `05_ACTIVE_MILESTONE_M020/MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md`

   Open a couple of them at random and confirm they are not empty or truncated.

3. **Compare SHA-256 hashes.**
   Use `00_START_HERE/SHA256SUMS.txt` to verify each file's checksum matches (e.g., on a computer: `sha256sum -c SHA256SUMS.txt` from inside the extracted package root; on phone, any SHA-256 checksum app pointed at each file will do).

4. **Delete old files from Claude Project Files only** — once, and only once, steps 2 and 3 both pass.

5. **Never delete historical documents from the real Git repository** at `C:\Users\LuxSy\Documents\trading`. This package only changes what is *visible to Claude inside this Claude Project's Files panel* — it has no effect on, and does not require any change to, the actual repository.

6. **Upload the Markdown files individually from the ZIP directories** — not the folders as archives, one file at a time from `01_MASTER_CONTEXT/`, `02_PROJECT_FOUNDATION/`, `03_FROZEN_ARCHITECTURE/`, `04_RECONSTRUCTION_M019/`, and `05_ACTIVE_MILESTONE_M020/`.

7. **Do not upload `SHA256SUMS.txt`** unless you specifically want it available for future reference — it is a verification aid, not project knowledge.

8. **Upload all 12 core Markdown/project files, not the ZIP alone.** Claude Project may not index files packaged inside a ZIP archive as independent documents — the ZIP is a **transport and verification container**, not the delivery format for Claude Project Files itself.

9. **After upload, start a new conversation** and ask Claude to read:
   - `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`
   - `PROJECT_OPERATING_MANUAL.md`
   - both active M020 documents (`MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` and `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md`).

10. **Require repository verification before any authoritative implementation or freeze claim.** Any session without direct, live Git access to `C:\Users\LuxSy\Documents\trading` may only produce `PORTABLE DESIGN CANDIDATE` work (per `PROJECT_OPERATING_MANUAL.md` Section 22) — never a claim of commit, test execution, or freeze.

Optionally, also upload `PROJECT_FILES_MANIFEST.md` from `00_START_HERE/` as a 13th reference document, so the active Claude Project explains its own reduced file set to any future reader.

---

## Exact Current Checkpoint

```text
PROJECT=Empirical Trading Platform
LATEST_FROZEN_MILESTONE=MILESTONE-019
LATEST_FROZEN_BASELINE=22c064691564955b0a1f2a3e9cb6791b61dd8261
CURRENT_MILESTONE=MILESTONE-020
CURRENT_SCOPE_BASELINE=7d802bc57f085564f682017051f419d69552fb62
CURRENT_DESIGN_COMMIT=8dd31a6dc947048beb4fa7d273b0c3e8c31e0183
CURRENT_STATUS=DESIGN_READY_FOR_INDEPENDENT_REVIEW
CURRENT_MISSION=M020_INDEPENDENT_DESIGN_REVIEW
REPOSITORY_VERIFICATION_REQUIRED=true
M020_FROZEN=false
```

> Note: `CURRENT_DESIGN_COMMIT` above is reproduced exactly as supplied and as it appears in `PROJECT_OPERATING_MANUAL.md` Section 30. It is flagged there (and in `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`, Conflict Register CONFLICT-0001) as **not independently verified** against the retrieved `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` text, which instead states its own baseline as `7d802bc57f085564f682017051f419d69552fb62`. This discrepancy remains **OPEN** and must be resolved against real Git history — do not treat either hash as confirmed without checking `git log` directly.
