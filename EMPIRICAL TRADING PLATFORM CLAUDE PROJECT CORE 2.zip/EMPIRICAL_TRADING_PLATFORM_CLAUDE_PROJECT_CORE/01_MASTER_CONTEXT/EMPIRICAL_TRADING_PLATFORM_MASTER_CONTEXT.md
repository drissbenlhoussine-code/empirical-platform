# Empirical Trading Platform — Master Context

## 1. Document Control

| Field | Value |
| --- | --- |
| Document name | EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md |
| Purpose | Consolidated navigation/continuation document synthesizing all milestone documents currently attached to this Claude Project |
| Generation date | 2026-07-23 |
| Source type | Markdown milestone documents attached to this Claude Project (`MILESTONE_001_006_...` through `MILESTONE_020_...`, `README.md`, `pyproject.toml`) |
| Authority limitation | This is a **navigation and continuation aid only**. It carries no independent authority. |
| Update policy | Regenerate from source milestone documents whenever milestones are added, corrected, or frozen. Do not hand-edit drift into this file without also updating the source milestones. |

> **This master context is a consolidated navigation and continuation document. Frozen milestone documents and verified Git history remain the ultimate authority.** Nothing in this document should be cited instead of the underlying milestone document it summarizes. This document was produced from a fixed set of attached files in a chat environment with **no direct Git access** — no command in this mission executed `git`, ran tests, or touched the real repository at `C:\Users\LuxSy\Documents\trading`. Every commit hash below is copied verbatim from source text, not independently re-verified against a working tree.

---

## 2. Platform Purpose

The Empirical Trading Platform (working repository name `empirical-platform`) is a **governance-aware, research-grade empirical validation platform**, not a trading bot. Its stated purpose (per `README.md` and the milestone lineage) is to support:

- **Reproducibility** — deterministic, typed, versioned domain behavior; immutable value objects; explicit transition history.
- **Auditability** — structured logging, correlation identifiers, explicit lifecycle transitions, evidence packages, and independent review as a first-class step in every milestone.
- **Evidence-driven decision-making** — Campaigns produce Runs, Runs produce Evidence Packages, Evidence Packages are Reviewed, and (in later, still-deferred work) a Decision Candidate / Decision Freeze process is meant to consume that evidence chain.
- **Separation from a simple trading bot** — the current product boundary is explicitly a research/validation platform. <br>The repository currently contains **no business logic, no empirical validation execution, no B3 criteria, no vendor adapters, no market-data acquisition, no production APIs beyond static health/version placeholders, no UI, no Decision Candidate creation, and no Decision Freeze.**
- **No profit guarantees** — nothing in the frozen milestones authorizes or implies trading/execution behavior; all such behavior is explicitly deferred.

Current product boundary: a **Python 3.13 foundation scaffold plus a growing, process-local (in-memory) domain model** for four aggregates (Campaign, Run, EvidencePackage, Review), plus infrastructure connectivity (PostgreSQL, S3-compatible object storage) that is **not yet wired to any domain schema**.

---

## 3. Mandatory Engineering Method

Every milestone in this project is required to move through this exact sequence:

```text
Design First -> Independent Review -> Correction Pass -> Freeze -> Scope Selection -> Implementation -> Hostile Review -> Verification -> Commit
```

Additional standing rules observed across every milestone document:

- **Quality over speed.** Milestones are frequently split into a scope-selection document and a separate design/implementation document precisely to avoid rushing.
- **No assumptions.** Ambiguous design questions are enumerated explicitly as "Required Scope Answers" or "Required Design Questions" rather than silently resolved.
- **No scope creep.** Every milestone document contains an explicit "Non-Goals" / "Explicit Non-Goals" section.
- **No modification of frozen decisions.** Later milestones consistently cite and preserve earlier frozen milestones (e.g., M016 preserves M012 aggregate definitions; M019 preserves M012–M018 lifecycle matrices).
- **Stop on repository discrepancy.** Every scope-selection and design document contains explicit "Stop Conditions."
- **Executable evidence before acceptance.** Implementation milestones report literal pytest/ruff/mypy/architecture-checker/security-scan command output before claiming "APPROVED AND FROZEN."

---

## 4. Architecture Principles

Consolidated from MILESTONE-005, MILESTONE-012, and MILESTONE-016/019/020:

- **Domain purity.** Aggregates (`Campaign`, `Run`, `EvidencePackage`, `Review`) contain no persistence, SQL, ORM, object-storage, API, or worker imports. This is enforced mechanically by `tools/check_architecture.py`, including deliberately-failing negative fixtures under `tests/fixtures/illegal_imports/`.
- **Governance/runtime identity separation.** Every aggregate identity is `DomainIdentity[XxxId]`, pairing a governance identifier (e.g., `CampaignId`, `RunId`, `EvidencePackageId`, `ReviewId`) with a separate runtime UUID. Repository/reconstruction contracts key off `DomainIdentity[...]`, never off the raw governance ID or the raw UUID alone.
- **Process-local aggregate behavior.** All four aggregates today are pure in-memory Python objects — no persistence exists yet. This is deliberate: aggregate behavior was frozen first (M013–M018), and reconstruction (M019) and repository/concurrency contracts (M020) were designed only after that behavior was stable.
- **Persistence neutrality.** Reconstruction state records (M019) and repository contracts (M020 design) are defined at a documentation level, independent of SQLAlchemy/psycopg/schema choices, which remain deferred.
- **Deterministic behavior / immutable value objects.** `CampaignScopeStatement`, `DatasetManifest`, `CriterionResult`, `ArtifactReference`, `StateTransitionRecord`, and `ReviewFinding` are frozen, hashable, and immutable. Collections are always exposed as tuples, never mutable lists.
- **Versioning.** Every aggregate carries an `AggregateVersion` that increments exactly once per accepted mutation (lifecycle transition or content mutation).
- **Transition sequencing / transition history.** Every aggregate carries a `TransitionSequence` (next-sequence counter) and an append-only tuple of `StateTransitionRecord`s, populated **only** by lifecycle transitions — not by content-only mutations (e.g., appending a Dataset Manifest or Criterion Result advances `AggregateVersion` but not `TransitionSequence`/history).
- **Rejection atomicity.** Every aggregate command validates all preconditions before mutating state; rejected commands leave identity, state, version, sequence, history, and content completely unchanged. This is tested explicitly ("snapshot and compare") in every aggregate-behavior milestone.
- **Reconstruction fidelity.** M019 reconstruction paths must reproduce exactly the aggregate state that would exist had all recorded transitions been applied — no normalization, sorting, merging, deduplication, or silent discarding of collection elements is permitted.
- **Architecture dependency rules.** Enforced directions include: `evidence -> {shared, identifiers}`, `review -> {shared, identifiers, evidence}` (not `acquisition`), `datasets -> campaign` allowed, `campaign -> datasets` **forbidden** (a load-bearing M016 decision), `run -> {datasets, identifiers, shared, campaign.lifecycle only}`.
- **Deferred cross-aggregate authority.** Reviewer independence, target existence/reviewability, Campaign completion preconditions (no active Runs, required Review dispositions), Evidence Package/Run/Campaign consistency, and all Audit/Decision Candidate/Decision Freeze behavior are explicitly classified as cross-aggregate or governance-gate concerns **outside** any single aggregate, and remain unimplemented.

---

## 5. Milestone Lineage

All commit hashes below are copied verbatim from the source milestone documents. Where a document states a baseline (pre-work) hash versus a final/frozen hash, both are shown where available.

| Milestone | Title | Type | Status | Baseline / commit evidence | Main deliverable | Deferred work | Source documents |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M001–M003 | Governance / Research / Engineering foundation (external, not separately attached) | External design references | Referenced only | N/A | Governance-aware platform concept, engineering blueprint, Python/PostgreSQL/S3 stack decisions | N/A | Referenced by `MILESTONE_001_006_DOCUMENT_INTEGRATION_REVIEW.md` |
| M004 | Repository Scaffolding and Toolchain Bootstrap | Implementation slice | APPROVED AND FROZEN | Registered 2026-07-13; no commit created at scaffold time ("No commits yet on master" in evidence) | `pyproject.toml`, package skeleton, CI, scripts, architecture checker, empty `migrations/` | Business logic, schemas, APIs beyond health/version | `MILESTONE_004_REPOSITORY_SCAFFOLDING_AND_TOOLCHAIN_BOOTSTRAP.md` |
| M005 | Infrastructure Architecture | Architecture spec (design-only) | APPROVED AND FROZEN (rev. 4) | N/A (design-only) | Layered infrastructure architecture (config, persistence, object-storage, time, identifiers, logging, error, health layers) | Code, contracts | `MILESTONE_005_INFRASTRUCTURE_ARCHITECTURE.md` |
| M006 | Foundation Contracts | Contract spec | APPROVED AND FROZEN (per M010 governing-documents table) | N/A (design-only) | Layer-scoped contracts (config, logging, identifier, time, error, health) | Implementation | `MILESTONE_006_FOUNDATION_CONTRACTS.md` |
| M001–M006 | Document Integration Review | Cross-document verification | Approved (v1.1) | N/A | Decision-lineage matrix M001→M006; verified M005/M006 traceability | N/A | `MILESTONE_001_006_DOCUMENT_INTEGRATION_REVIEW.md` |
| M007 | First Infrastructure Implementation Slice | Implementation slice | APPROVED AND FROZEN (per M010 governing-documents table) | N/A confirmed in this document set | Process-local foundation runtime (config, logging, clocks, identifiers, health) | Persistence, object storage | `MILESTONE_007_FIRST_INFRASTRUCTURE_IMPLEMENTATION_SLICE.md` |
| M008 | Persistence Connectivity Foundation Slice | Implementation slice | APPROVED AND FROZEN | N/A confirmed in this document set | PostgreSQL pool/UoW connectivity, no schema | Domain schema, repositories | `MILESTONE_008_PERSISTENCE_CONNECTIVITY_FOUNDATION_SLICE.md` |
| M009 | Object Storage Connectivity Foundation Slice | Implementation slice | APPROVED AND FROZEN | N/A confirmed in this document set | S3/MinIO client connectivity, no object layout | Bucket/key layout, retention policy | `MILESTONE_009_OBJECT_STORAGE_CONNECTIVITY_FOUNDATION_SLICE.md` |
| M010 (scope) | Scope Selection and Architecture Gap Review | Scope selection | Committed at baseline (informs M010 impl.) | Baseline referenced: `93cb111445439b53f986480e8695716619a973bb` used as M010 implementation baseline | Selected "Unified Infrastructure Runtime Composition" as next scope | Registry, job ledger/outbox, campaign models | `MILESTONE_010_SCOPE_SELECTION_AND_ARCHITECTURE_GAP_REVIEW.md` |
| M010 (impl) | Unified Infrastructure Runtime Composition | Implementation | APPROVED AND FROZEN | Baseline `93cb111445439b53f986480e8695716619a973bb` | `FoundationRuntime`: combined PostgreSQL+object-storage startup/shutdown/health | Domain schemas, registry, job ledger, APIs, workers | `MILESTONE_010_UNIFIED_INFRASTRUCTURE_RUNTIME_COMPOSITION.md` |
| M011 | Scope Selection and Architecture Gap Review | Scope selection | SCOPE SELECTED / DESIGN MILESTONE REQUIRED | Baseline `b8f3f91240aff7d743d20577ef0fd658f74cf28a` | Identified need for a canonical runtime domain-kernel design (→ M012) | Domain kernel design itself | `MILESTONE_011_SCOPE_SELECTION_AND_ARCHITECTURE_GAP_REVIEW.md` |
| M012 (design) | Canonical Runtime Domain Kernel Design | Design | APPROVED AND FROZEN (v1.2, corrected) | Repository baseline `274a3ffbaac19ea449f80bc6c87befa46fb89c7c` | Defines Campaign/Run/EvidencePackage/Review as the initial aggregate roots; Dataset Manifest and Criterion Result as owned records | Schemas, repositories, APIs, workers, Audit, Decision Candidate | `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_DESIGN.md` |
| M012 (independent review) | Canonical Runtime Domain Kernel Independent Review | Independent review | REVISION REQUIRED (score 67/100 on first pass) | N/A | Identified lifecycle/disposition conflations, identifier issues, entity-necessity concerns | Corrected by M012 design v1.2 | `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_INDEPENDENT_REVIEW.md` |
| M012 (external reconciliation) | External Artifact Registration and Baseline Reconciliation | Acceptance evidence | BASELINE RECONCILED — AUTHORITY CLASSIFIED (score 99/100) | Same as M012 design baseline | Registered 21 external artifacts; classified 0 as "AUTHORITATIVE FROZEN BASELINE," 14 "DRAFT/INFORMATIVE," 7 "UNRESOLVED AUTHORITY" | N/A | `MILESTONE_012_EXTERNAL_ARTIFACT_REGISTRATION_AND_BASELINE_RECONCILIATION.md` |
| M012 (authority correction) | Authority and Freeze Readiness Correction | Governance correction | AUTHORITY CLASSIFIED — READY TO FREEZE | Repository baseline `274a3ffbaac19ea449f80bc6c87befa46fb89c7c` | Resolved `MILESTONE-012-ACCEPTANCE-ISSUE-0001`; cleared M012 for freeze | N/A | `MILESTONE_012_AUTHORITY_AND_FREEZE_READINESS_CORRECTION.md` |
| M013 (scope) | Domain Kernel Implementation Scope Selection | Scope selection | IMPLEMENTATION SLICE READY | Baseline `cb10fe87b2d2ac171a4ad4d6b0987f423e5a887f` | Selected process-local domain primitive slice as next implementation | Aggregate behavior itself | `MILESTONE_013_DOMAIN_KERNEL_IMPLEMENTATION_SCOPE_SELECTION.md` |
| M013 (impl) | Process-Local Domain Primitive Foundation | Implementation slice | APPROVED AND FROZEN | Baseline `8a5f1eb1e4eb850ea46f7f8d8ad355318cbe2cbe` | Lifecycle enums (Campaign/Run/EvidencePackage/Review), `ReviewDisposition`, `AggregateVersion`, `TransitionSequence`, `StateTransitionRecord`, `DomainIdentity`/`pair_identity`, `DatasetManifest`, `CriterionResult` | Aggregate root behavior | `MILESTONE_013_PROCESS_LOCAL_DOMAIN_PRIMITIVE_FOUNDATION.md` |
| M014 (scope) | Process-Local Aggregate Behavior Scope Selection | Scope selection | Evidence Package selected (Candidate C over Campaign Candidate A) | N/A explicit hash in retrieved excerpts | Selected Evidence Package as first aggregate-behavior slice | Campaign, Run, Review behavior | `MILESTONE_014_PROCESS_LOCAL_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` |
| M014 (impl) | Process-Local Evidence Package Aggregate Behavior | Implementation slice | APPROVED AND FROZEN | Frozen architecture baseline `09bbce8e750deff730e250e35cd5a9cf8b1fe5e1`; implementation baseline `68bddce850552299ba3faf8a94cb328f312ccb60` | `EvidencePackage` aggregate root + `ArtifactReference` value object | Campaign, Run, Review behavior | `MILESTONE_014_PROCESS_LOCAL_EVIDENCE_PACKAGE_AGGREGATE_BEHAVIOR.md` |
| M015 (scope) | Process-Local Review Aggregate Behavior Scope Selection | Scope selection | SCOPE CANDIDATE SELECTED | Baseline `7df44603bfc3dc4096449417f6e343eee15ed919` (= M014 frozen commit) | Selected Review (Evidence-Package-target only) as next slice | Run-target Review, reviewer independence gate | `MILESTONE_015_PROCESS_LOCAL_REVIEW_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` |
| M015 (impl) | Process-Local Review Aggregate Behavior | Implementation slice | IMPLEMENTED / AWAITING INDEPENDENT FREEZE REVIEW at time of writing; treated as frozen by M016 (baseline `e864d72c000911ed6cfa6fd137b5db3cd353c733` = "MILESTONE-015 approved and frozen") | See baseline above | `Review` aggregate root, `ReviewFinding` | Run, Campaign behavior | `MILESTONE_015_PROCESS_LOCAL_REVIEW_AGGREGATE_BEHAVIOR.md` |
| M016 (scope) | Run Aggregate Boundary Reconciliation Scope Selection | Scope selection (architecture boundary) | SCOPE CANDIDATE SELECTED | Baseline `e864d72c000911ed6cfa6fd137b5db3cd353c733` | Selected a documentation-only boundary-reconciliation milestone before Run implementation | Run implementation itself | `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_SCOPE_SELECTION.md` |
| M016 (decision) | Run Aggregate Boundary Reconciliation Decision | Architecture boundary decision | APPROVED AND FROZEN | Baseline `91be63a212af8c1113652d8fe53c6dcdfc327e91` | Decided `campaign -> datasets` stays forbidden; `RunLifecycleState` stays physically in `campaign`; future Run package will be new top-level `run` | Run package creation, architecture-rule update | `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_DECISION.md` |
| M017 (scope) | Process-Local Run Aggregate Behavior Scope Selection | Scope selection | Scope defined (lifecycle matrix, manifest ownership) | N/A explicit hash in retrieved excerpts | Fixed exact Run lifecycle matrix and Dataset Manifest ownership rules | Run implementation | `MILESTONE_017_PROCESS_LOCAL_RUN_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` |
| M017 (impl) | Process-Local Run Aggregate Behavior | Implementation | APPROVED AND FROZEN | Frozen architecture baseline `17e4a43fe97ca3fa23b5c9aedc54f65a7b7d0d52`; implementation baseline `44141a2034bf5cffd97273e5b519caf4ac28fbb0` | `Run` aggregate root (`empirical_platform.run.aggregate`) | Campaign behavior, repositories | `MILESTONE_017_PROCESS_LOCAL_RUN_AGGREGATE_BEHAVIOR.md` |
| M018 (scope) | Process-Local Campaign Aggregate Behavior Scope Selection | Scope selection | Campaign aggregate selected (completes initial aggregate-root set) | N/A explicit hash in retrieved excerpts | Selected Campaign as final initial-aggregate slice; produced dependency graph M012→M020 | Repository contracts, schema/migrations, Audit, Decision Candidate | `MILESTONE_018_PROCESS_LOCAL_CAMPAIGN_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` |
| M018 (impl) | Process-Local Campaign Aggregate Behavior | Implementation | Frozen (referenced by M019 scope selection as "MILESTONE-018 hostile-review hardening commit") | Baseline used downstream: `da3153fc3a0d5a277958d62a53711cfd76495d4b` | `Campaign` aggregate root, `CampaignScopeStatement` | Run-relationship tracking (explicitly excluded), repositories | `MILESTONE_018_PROCESS_LOCAL_CAMPAIGN_AGGREGATE_BEHAVIOR.md` |
| M019 (scope) | Aggregate Reconstruction Contract Scope Selection | Scope selection | SCOPE CANDIDATE SELECTED | Baseline `da3153fc3a0d5a277958d62a53711cfd76495d4b` | Selected reconstruction-contract design for all four aggregates together | Repository/mapper/schema work | `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_SCOPE_SELECTION.md` |
| M019 (design) | Aggregate Reconstruction Contract Design | Design | APPROVED AND FROZEN | Frozen design baseline `6afb28028197ffd77a11708e15a671b2a97e3837` | Documentation-level `*ReconstructionState` records, `ReconstructionError`/`ReconstructionErrorCategory`, validation/trust rules | Implementation | `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_DESIGN.md` |
| M019 (impl. scope) | Aggregate Reconstruction Contract Implementation Scope Selection | Scope selection | IMPLEMENTATION SCOPE CANDIDATE SELECTED | Frozen design baseline `6afb28028197ffd77a11708e15a671b2a97e3837` | Fixed exact module/factory names (`_reconstruction`, `_reconstruct_*`, `object.__new__`) | Implementation itself | `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION_SCOPE_SELECTION.md` |
| M019 (impl) | Aggregate Reconstruction Contract Implementation | Implementation | IMPLEMENTATION COMPLETE — PENDING INDEPENDENT REVIEW at time of writing; later frozen (see below) | Baseline `2200357194bf44ce0c60b0b2160b0605f2455b54` | `shared/domain/reconstruction.py` + per-aggregate `_reconstruction.py` modules for Campaign, Run, Evidence, Review | Repository contracts | `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md` |
| M019 (final freeze) | — | Freeze evidence (referenced by M020 documents) | **APPROVED AND FROZEN** | `22c064691564955b0a1f2a3e9cb6791b61dd8261` (cited by M020 scope selection as "MILESTONE-019 APPROVED AND FROZEN" and matches the checkpoint block's `LATEST_FROZEN_BASELINE`) | Final frozen reconstruction contract for all 4 aggregates | Repository contracts (→ M020) | Referenced in `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` |
| M020 (scope) | Domain Repository and Concurrency Contract Scope Selection | Scope selection | SCOPE CANDIDATE SELECTED | Frozen baseline `22c064691564955b0a1f2a3e9cb6791b61dd8261`; produced next design baseline `7d802bc57f085564f682017051f419d69552fb62` | Enumerated required repository/concurrency design questions for all four aggregates | Design itself | `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` |
| M020 (design) | Domain Repository and Concurrency Contract Design | Design | **DESIGN READY FOR INDEPENDENT REVIEW** (NOT FROZEN) | Design baseline `7d802bc57f085564f682017051f419d69552fb62`; per the operator-supplied checkpoint block, the (not yet independently re-verified in retrieved text) design commit awaiting review is `8dd31a6dc947048beb4fa7d273b0c3e8c31e0183` | `get`/`add`/`save` contracts, `AggregateNotFound`, `AggregateAlreadyExists`, `OptimisticConcurrencyConflict`, `InvalidPersistedAggregateState`, `SaveResult`, four-term version vocabulary | Independent review, correction, implementation | `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` |

---

## 6. Frozen Domain Primitives

From MILESTONE-013 (`empirical_platform.shared.domain`, `empirical_platform.identifiers`, and per-aggregate packages):

| Primitive | Package | Description |
| --- | --- | --- |
| `CampaignLifecycleState` | `campaign` | Enum: `DRAFT`, `READY_FOR_AUTHORIZATION`, `AUTHORIZED`, `ACTIVE`, `SUSPENDED`, `COMPLETED`, `CANCELLED` |
| `RunLifecycleState` | `campaign` (physically; conceptually owned by Run) | Enum: `CREATED`, `AUTHORIZED`, `ACQUIRING`, `NORMALIZING`, `VALIDATING`, `EXECUTION_COMPLETED`, `FAILED`, `CANCELLED` |
| `EvidencePackageLifecycleState` | `evidence` | Enum: `INITIALIZED`, `COLLECTING`, `SEALED`, `INVALIDATED` |
| `ReviewLifecycleState` | `review` | Enum: `ASSIGNED`, `IN_PROGRESS`, `COMPLETED`, `CANCELLED` |
| `ReviewDisposition` | `review` | Enum, separate from lifecycle: `ACCEPTED`, `REJECTED`, `CHANGES_REQUESTED`, `INCONCLUSIVE` |
| `DomainIdentity[T]` / `pair_identity` | `identifiers` | Pairs a governance ID (`CampaignId`, `RunId`, `EvidencePackageId`, `ReviewId`, etc.) with a separate runtime UUID |
| `AggregateVersion` | `shared.domain` | Monotonic content/lifecycle version counter; `.initial()`, `.next()` |
| `TransitionSequence` | `shared.domain` | Monotonic lifecycle-transition counter; `.initial()`, `.next()` |
| `StateTransitionRecord[Identity]` | `shared.domain` | Immutable record of one lifecycle transition (from/to state, sequence, version, actor, timestamp, reason, correlation ID) |
| `DatasetManifest` | `datasets` | Immutable, Run-owned record; storage-layout-neutral |
| `CriterionResult` | `evidence` | Immutable, Evidence-Package-owned entity; not an aggregate root |
| `ArtifactReference` | `evidence` | Opaque immutable value object (string-like reference; no path/URI/bucket/key/checksum semantics) |
| `CampaignScopeStatement` | `campaign` | Frozen dataclass with single `value: str` field |
| `ReviewFinding` | `review` | Bounded immutable owned record with local positive sequence number, finding text, optional rationale, optional evidence-reference strings |

Governance identifier namespaces registered (per M012 reconciliation): `CAMP`, `RUN`, `DATASET`, `EVID`, `REVIEW`, `AUD` (deferred with Audit), `DCAND` (deferred with Decision Candidate), plus `DEC`, `RES`, `SRC`, `ASS`, `CONF`, `RISK`, `DEF` at the governance layer (not runtime identity).

---

## 7. Frozen Aggregate Inventory

### 7.1 Campaign (`empirical_platform.campaign.aggregate`, frozen M018)

- **Identity:** `DomainIdentity[CampaignId]`, immutable after construction.
- **Parent/context identity:** none (top-level root).
- **Lifecycle states:** `DRAFT → READY_FOR_AUTHORIZATION → AUTHORIZED → ACTIVE ⇄ SUSPENDED → COMPLETED`; `cancel` reachable from `DRAFT`, `READY_FOR_AUTHORIZATION`, `AUTHORIZED`, `ACTIVE`, `SUSPENDED`.
- **Terminal states:** `COMPLETED`, `CANCELLED`.
- **Owned values:** `CampaignScopeStatement` (replaceable only in `DRAFT`).
- **Owned collections:** none (explicitly stores **no** Run IDs/summaries — Run relationship is cross-aggregate and deferred).
- **Duplicate rules:** N/A (no owned collection).
- **Version effects:** every accepted lifecycle transition +1; accepted scope-statement replacement +1 (no sequence/history change).
- **Sequence/history effects:** every accepted lifecycle transition consumes current sequence, advances next sequence, appends one `StateTransitionRecord`.
- **Atomic rejection:** validated fully before any mutation; rejected commands leave identity/state/version/sequence/history/scope-statement unchanged.
- **Local invariants:** readiness/authorization/activation/completion/cancellation are purely local recording operations — no Run or Review inspection occurs inside Campaign.
- **Deferred cross-aggregate invariants:** Campaign completion requiring "no active Runs" and "required Review dispositions" (mentioned as a real invariant in M014 scope analysis) remains **unimplemented** — Campaign today performs no such check.
- **Frozen baseline:** implementation frozen at the commit referenced downstream as `da3153fc3a0d5a277958d62a53711cfd76495d4b` ("MILESTONE-018 hostile-review hardening commit").

### 7.2 Run (`empirical_platform.run.aggregate`, frozen M017)

- **Identity:** `DomainIdentity[RunId]`, immutable.
- **Parent/context identity:** immutable `CampaignId` (stored only; Campaign is never loaded or mutated).
- **Lifecycle states:** `CREATED → AUTHORIZED → ACQUIRING → NORMALIZING → VALIDATING → EXECUTION_COMPLETED`; `AUTHORIZED → CANCELLED`; `ACQUIRING/NORMALIZING/VALIDATING → FAILED`.
- **Terminal states:** `EXECUTION_COMPLETED`, `FAILED`, `CANCELLED`.
- **Owned collections:** bounded, append-only tuple of `DatasetManifest` records, ordered by append sequence; supersession = append new record, never destructive edit.
- **Duplicate rules:** duplicate non-null `manifest_id` rejected; repeated `None` manifest IDs allowed.
- **Version/sequence/history effects:** lifecycle transitions advance version + sequence + history; manifest append/supersession advances version only.
- **Atomic rejection:** invalid transition, wrong manifest Run ID, duplicate manifest identity, invalid actor/timestamp/reason, or terminal mutation attempts leave state unchanged.
- **Local invariants:** identity immutable; Campaign context immutable; lifecycle legality; manifest Run-ID match; manifest immutability; terminal immutability.
- **Deferred cross-aggregate invariants:** Campaign authorization, entitlement/license validity, Evidence Package seal state, Review dispositions, Audit, Decision Candidate sufficiency.
- **Frozen baseline:** architecture baseline `17e4a43fe97ca3fa23b5c9aedc54f65a7b7d0d52`; implementation baseline `44141a2034bf5cffd97273e5b519caf4ac28fbb0`.

### 7.3 EvidencePackage (`empirical_platform.evidence.package`, frozen M014)

- **Identity:** `DomainIdentity[EvidencePackageId]`, immutable.
- **Parent/context identity:** immutable `RunId` (stored only; Run is never loaded or mutated).
- **Lifecycle states:** `INITIALIZED → COLLECTING → SEALED → INVALIDATED`.
- **Terminal states:** none formally named "terminal," but `SEALED`/`INVALIDATED` reject all content mutation; no `unseal` exists.
- **Owned collections:** tuple of `CriterionResult`; tuple of `ArtifactReference`. Both mutable only during `COLLECTING`.
- **Duplicate rules:** duplicate `CriterionResult.criterion_id` rejected; duplicate exact `ArtifactReference.value` rejected.
- **Version effects:** every lifecycle transition +1; every accepted content addition +1 (no sequence/history change for content).
- **Sequence/history effects:** lifecycle transitions only (`start_collection`, `seal`, `invalidate`).
- **Seal requirement:** at least one `CriterionResult` and one `ArtifactReference`.
- **Invalidation:** allowed only after `SEALED`, requires non-empty reason, preserves sealed contents.
- **Atomic rejection:** validated before mutation; snapshot-compared in tests across identity/RunId/state/version/sequence/history/collections.
- **Deferred cross-aggregate invariants:** Run existence/active-state, Dataset Manifest compatibility, Review target validity, reviewer independence, object-storage existence/checksum verification.
- **Frozen baseline:** architecture baseline `09bbce8e750deff730e250e35cd5a9cf8b1fe5e1`; implementation baseline `68bddce850552299ba3faf8a94cb328f312ccb60`.

### 7.4 Review (`empirical_platform.review`, frozen M015)

- **Identity:** `DomainIdentity[ReviewId]`, immutable.
- **Parent/context identity:** immutable target reference — for M015, restricted to target kind `EVIDENCE_PACKAGE` + `EvidencePackageId` only (Run-target Review deferred).
- **Lifecycle states:** `ASSIGNED → IN_PROGRESS → COMPLETED`; `→ CANCELLED` from an active state with required cancellation reason.
- **Terminal states:** `COMPLETED`, `CANCELLED`.
- **Owned collections:** bounded, append-only tuple of `ReviewFinding` (positive local sequence numbers, non-empty text, optional rationale, optional evidence-reference strings). Appendable only while `IN_PROGRESS`.
- **Duplicate rules:** duplicate finding *text* is allowed (findings are not deduplicated); non-contiguous sequence is rejected.
- **Disposition:** separate primitive from lifecycle (`ReviewDisposition`); set only at completion, requires ≥1 finding + non-empty final rationale.
- **Version/sequence/history effects:** appending a finding +1 version only; completion/cancellation +1 version + sequence + history.
- **Atomic rejection:** identity/target/reviewer-reference/state/version/sequence/history/findings/disposition unchanged on rejection.
- **Local invariants:** reviewer reference stored as an opaque non-empty string (no authority/authentication check inside the aggregate).
- **Deferred cross-aggregate invariants:** target existence/lifecycle validation, reviewer independence/conflict-of-interest enforcement, duplicate-active-Review-per-target prevention, stale-review reconciliation after evidence invalidation.
- **Frozen baseline:** implemented at the commit later referenced as `e864d72c000911ed6cfa6fd137b5db3cd353c733` ("MILESTONE-015 approved and frozen").

---

## 8. Reconstruction Architecture (MILESTONE-019)

- **Problem:** aggregates could be created and mutated in-memory, but could not yet be safely restored from durable metadata without either re-running business logic (wrong — would re-trigger version/sequence/history side effects) or exposing public "load" constructors (wrong — would weaken encapsulation).
- **State records:** documentation-level, aggregate-specific `*ReconstructionState` records (`CampaignReconstructionState`, `RunReconstructionState`, `EvidencePackageReconstructionState`, `ReviewReconstructionState`) enumerate every field needed to rebuild each aggregate, each field classified as **STRUCTURALLY VALIDATED** and/or **INTERNALLY CONSISTENCY-VALIDATED**.
- **Internal factory modules:** one per aggregate package, all named with a leading underscore: `campaign/_reconstruction.py`, `run/_reconstruction.py`, `evidence/_reconstruction.py`, `review/_reconstruction.py`, plus a shared `shared/domain/reconstruction.py`.
- **Factory names:** `_reconstruct_*` (underscore-prefixed, package-internal only; never publicly exported).
- **`object.__new__` mechanism:** reconstruction bypasses normal `__init__` via `object.__new__`, populating private fields directly rather than replaying business methods.
- **Error model:** one shared `ReconstructionError(category, message, *, field=None, context=None)` plus `ReconstructionErrorCategory` enum — no database/SQLAlchemy/psycopg/S3/MinIO/repository/runtime error category was added to this taxonomy.
- **Validation/trust classes:** every supplied field is either "structurally validated" (type/shape correctness) or additionally "internally consistency-validated" (cross-field correctness, e.g. version vs. history length).
- **Version floors:** current `AggregateVersion` must be consistent with the supplied `transition_history` and content.
- **History validation:** the record type must be canonical; identity must match or be absent; `from_state`/`to_state` must be valid and allowed by the frozen lifecycle matrix; the *first* record must start from the aggregate's canonical initial state; sequence order must follow the "last record sequence N ⇒ aggregate `next_transition_sequence == N+1`" rule; terminal transitions must not be followed by later records. Timestamp monotonicity is explicitly **not** required or invented.
- **Collection validation:** per-aggregate rules for Run manifests, EvidencePackage Criterion Results/ArtifactReferences, and Review findings — see the table in MILESTONE-019 §19 (duplicate rules match the aggregate-behavior rules in Section 7 above). No reconstruction path may normalize, sort, merge, deduplicate, overwrite, or silently discard collection elements.
- **Terminal metadata:** e.g., Run failure/cancellation reasons live only in transition history; `EXECUTION_COMPLETED` has no separate terminal-metadata field.
- **Visibility:** reconstruction factories and state records are never publicly exported; only "authorized mapper/repository implementation code" (still to be built) is meant to import them.
- **Architecture rules:** negative fixtures exist proving that `campaign` and `review` packages are rejected if they attempt persistence-layer or SQLAlchemy imports.
- **External review package evidence:** the M019 implementation was independently reviewed (`MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION_SCOPE_SELECTION.md` §21) and all findings were resolved.
- **Frozen baseline:** design frozen at `6afb28028197ffd77a11708e15a671b2a97e3837`; implementation completed at `2200357194bf44ce0c60b0b2160b0605f2455b54`; final freeze evidenced downstream at `22c064691564955b0a1f2a3e9cb6791b61dd8261`.

---

## 9. Persistence and Infrastructure Inventory

| Capability | Status | Evidence |
| --- | --- | --- |
| PostgreSQL connectivity (pool, Unit-of-Work primitive) | IMPLEMENTED AND VERIFIED, no domain schema | `shared/persistence/postgres.py` (M008, M010) |
| S3-compatible object-storage connectivity (MinIO-compatible client) | IMPLEMENTED AND VERIFIED, no object layout | `shared/object_storage/s3.py` (M009, M010) |
| Unified infrastructure runtime (`FoundationRuntime`) | IMPLEMENTED AND VERIFIED | `shared/bootstrap.py` — all-or-nothing startup, reverse-order cleanup, ordered/idempotent shutdown, combined health (M010) |
| Domain repository interfaces | NOT YET IMPLEMENTED | M020 is design-only, not frozen |
| Domain schema / migrations | EXPLICITLY DEFERRED — `migrations/versions` remains empty through M020 | Confirmed repeatedly through M008–M020 |
| Transactional outbox / job ledger | EXPLICITLY DEFERRED | M010 scope review §7 |
| Governance registry read model | DESIGNED ONLY (package skeleton) | M010 scope review §5 |
| Campaign/Run/Dataset/Evidence *persistence* models | DESIGNED ONLY (package skeletons only; in-memory aggregate behavior exists, persistence does not) | M010 scope review §5 |
| APIs / workers | EXPLICITLY DEFERRED beyond static health/version placeholders | README.md, all milestones |
| Trading / vendor / market-data behavior | EXPLICITLY DEFERRED, not present anywhere in source tree | README.md, all milestones |

---

## 10. M020 Current State

```text
Latest fully frozen baseline:            22c064691564955b0a1f2a3e9cb6791b61dd8261
M020 approved scope baseline:            7d802bc57f085564f682017051f419d69552fb62
M020 design commit awaiting independent review: 8dd31a6dc947048beb4fa7d273b0c3e8c31e0183
Current milestone:  MILESTONE-020 — Domain Repository and Concurrency Contract Design
Current status:     DESIGN READY FOR INDEPENDENT REVIEW
Freeze status:       NOT FROZEN / PENDING INDEPENDENT REVIEW
Current mission:     Independent hostile review, correction pass if required, validation,
                     external-review package, and freeze decision for M020 design.
```

> Note on the design-commit hash: the retrieved `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` text states its own **design baseline** (the commit it was written *against*) as `7d802bc57f085564f682017051f419d69552fb62`, and states explicitly that this document itself is **not staged/committed**. The hash `8dd31a6dc947048beb4fa7d273b0c3e8c31e0183` for "the M020 design commit awaiting independent review" was supplied by the operator's instruction rather than observed verbatim inside the retrieved document text in this environment. Treat it as **operator-asserted**, not independently re-derived here, and reconcile against real Git history when repository access exists.

### M020 proposed design (summarized — NOT frozen)

- **Aggregate-specific repositories**, not one generic `Repository[Identity, Aggregate]` — rejected generic abstraction as premature/domain-language-erasing.
- **Aggregate-local repository modules** (placed near, but not inside, each aggregate package; reconstruction internals stay `_`-private).
- **Synchronous contracts** (async conversion, if ever needed, happens at the application/runtime boundary, not in the domain contract).
- **Detached aggregates** — no identity-map/tracked-session semantics; callers must explicitly pass an `expected_persisted_version` to `save`.
- **`DomainIdentity[AggregateId]` input** for `get`/`add`/`save` (not raw governance IDs, not raw UUIDs).
- **`get`/`add`/`save` operation names:**
  - `get(identity)` → detached aggregate root, or raises `AggregateNotFound`; raises `InvalidPersistedAggregateState` on malformed/failed reconstruction.
  - `add(aggregate)` → for a **new** aggregate only; raises `AggregateAlreadyExists` on duplicate identity (including races — exactly one caller must win).
  - `save(aggregate, expected_persisted_version)` → for an **existing** aggregate; atomically compares durable version to `expected_persisted_version`; raises `OptimisticConcurrencyConflict` on mismatch.
- **Four-term version vocabulary:** *aggregate current version*, *expected persisted version*, *persisted version after save*, *new aggregate state* (no persisted version yet).
- **`SaveResult`** returned by `add`/`save`, carrying at least an operation marker (e.g. `CREATED`/`UPDATED`/`UNCHANGED`) and the persisted version after save.
- **Repository error taxonomy:** `AggregateNotFound`, `AggregateAlreadyExists`, `OptimisticConcurrencyConflict`, `InvalidPersistedAggregateState` — deliberately **not** including infrastructure/availability errors (those stay in the existing `FoundationError` taxonomy, kept separate).
- **Reconstruction integration:** `future repository → future persistence mapper → aggregate-owned internal _reconstruction module → aggregate`; repository contracts see only aggregates and identities, never reconstruction state records.
- **Atomic save boundary:** one aggregate root + its owned collections + transition history persisted atomically per `save`/`add` call; cross-aggregate transactions and Unit-of-Work integration remain explicitly deferred.
- **Excluded from M020:** query/list/delete operations, read models, row locking, caching, transaction-context parameters on the public contract, mapper/schema/SQL/migration work, Unit-of-Work implementation.

---

## 11. M020 Open Review Questions

1. Is `DomainIdentity[AggregateId]` lookup (rather than raw governance ID or raw UUID) actually feasible/efficient once a real schema exists?
2. How exactly does `get`/`load` communicate the "expected persisted version" back to the caller — is it implicit (caller must separately track it) or should `get` return something richer than a bare aggregate?
3. Should `get` return the aggregate root only, or a wrapper such as `LoadedAggregate` bundling the aggregate with its persisted version?
4. What happens if `save` is called for an aggregate whose identity has no durable row at all (missing durable identity) — is that `AggregateNotFound`, a different error, or undefined?
5. What happens if the aggregate's in-memory current version is *lower* than the expected persisted version supplied by the caller (a state the design currently only partially addresses via "current version must be ≥ expected persisted version")?
6. What is the **exact** module and shape of `SaveResult` (fields, enum values, immutability)?
7. What is the **exact** module and field shape of each error type (`AggregateNotFound`, `AggregateAlreadyExists`, `OptimisticConcurrencyConflict`, `InvalidPersistedAggregateState`)?
8. What exact import permissions will future mapper/repository implementation code have into aggregate-package `_reconstruction` modules, and how will that be enforced by `tools/check_architecture.py`?
9. Is a fully synchronous contract suitable long-term, or will API/worker integration eventually force an async wrapper layer — and if so, where does that boundary live?
10. Is repeating an unchanged `save` call (same aggregate, same expected version, no actual content difference) valid, and is it required to be idempotent/deterministic in its `SaveResult`?

---

## 12. Deferred Roadmap

**Near-term (already scoped/ordered by frozen milestones):**

1. M020 independent design review (hostile review against the questions in Section 11).
2. M020 correction pass (if required) and freeze decision.
3. M020 implementation scope selection.
4. Repository contract **source implementation** (not yet begun — no repository code exists in the repository today).
5. Hostile review and freeze of the M020 implementation.

**Later (explicitly deferred by every milestone that touches them — not authorized by this document):**

- Persistence mapper design and implementation.
- PostgreSQL schema design and Alembic migrations (`migrations/versions` is still empty).
- Concrete PostgreSQL repository implementations.
- Transaction integration / Unit-of-Work promotion.
- Application services and command handlers.
- Audit runtime.
- Decision Candidate runtime.
- Decision Freeze.
- Trading, vendor, market-data, and execution layers.
- Run-target Review, reviewer-independence enforcement, Campaign↔Run↔Review cross-aggregate invariant enforcement.

No deferred milestone above is authorized by this document.

---

## 13. Explicit Prohibitions

- No changing any frozen decision (M004–M019, and M020 once frozen) without a reviewed correction milestone.
- No generic repository abstraction adopted "by habit" — M020 explicitly rejected `Repository[Identity, Aggregate]` as premature.
- No speculative CRUD — no `list`/`query`/`delete` in repository contracts unless a future milestone justifies it with evidence.
- No public reconstruction APIs — `_reconstruction` modules and `_reconstruct_*` factories must stay package-internal.
- No SQL/ORM/SQLAlchemy/psycopg imports inside any domain aggregate or reconstruction module.
- No schemas before mapper/contract design is frozen.
- No migration creation before schema design is authorized.
- No Unit-of-Work promotion without evidence-backed design.
- No trading features outside the currently selected scope.
- No false claims of Git verification, test execution, commit, implementation acceptance, or milestone freeze from a chat/phone-only environment without real repository access.

---

## 14. Conflict Register

| ID | Documents | Conflicting statements | Frozen authority evidence | Resolution | Status |
| --- | --- | --- | --- | --- | --- |
| CONFLICT-0001 | `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` (retrieved text) vs. operator-supplied checkpoint block | The retrieved design document states its own baseline commit as `7d802bc57f085564f682017051f419d69552fb62` and states it is not committed; the operator's checkpoint block asserts a distinct "design commit awaiting independent review" of `8dd31a6dc947048beb4fa7d273b0c3e8c31e0179`… (`8dd31a6dc947048beb4fa7d273b0c3e8c31e0183`) as though it is already a real commit. | None of the retrieved document text itself contains that second hash. | Both hashes are recorded verbatim in Section 10 with the discrepancy flagged; do not treat the second hash as independently verified until checked against real Git history. | OPEN |
| CONFLICT-0002 | `MILESTONE_015_PROCESS_LOCAL_REVIEW_AGGREGATE_BEHAVIOR.md` ("IMPLEMENTED / AWAITING INDEPENDENT FREEZE REVIEW") vs. `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_SCOPE_SELECTION.md` (treats baseline `e864d72c000911ed6cfa6fd137b5db3cd353c733` as "MILESTONE-015 approved and frozen") | M015's own implementation report ends in an unfrozen state; M016 (a later, frozen document) asserts M015 was subsequently approved and frozen at a specific commit. | M016 is itself APPROVED AND FROZEN and depends on M015 being frozen; no separate M015-freeze document was found among attached files. | RESOLVED by later freeze evidence — M016's explicit reliance on a frozen M015 baseline is treated as authoritative confirmation that the M015 freeze occurred, even though the standalone M015 freeze report was not separately attached to this project. | RESOLVED |
| CONFLICT-0003 | `MILESTONE_018_PROCESS_LOCAL_CAMPAIGN_AGGREGATE_BEHAVIOR.md` (implementation report, no explicit "APPROVED AND FROZEN" banner retrieved) vs. `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_SCOPE_SELECTION.md` (treats baseline `da3153fc3a0d5a277958d62a53711cfd76495d4b` as "MILESTONE-018 hostile-review hardening commit," implying frozen) | Similar pattern to CONFLICT-0002: downstream milestone treats M018 as frozen. | M019 scope selection is itself frozen evidence and depends on M018 being frozen. | RESOLVED by later freeze evidence, same reasoning as CONFLICT-0002. | RESOLVED |
| CONFLICT-0004 | `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md` ("IMPLEMENTATION COMPLETE - PENDING INDEPENDENT REVIEW") vs. `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` (treats baseline `22c064691564955b0a1f2a3e9cb6791b61dd8261` as "MILESTONE-019 APPROVED AND FROZEN") | Same freeze-lag pattern as above, one level up the chain. | M020 scope selection depends on M019 being frozen and is consistent with the operator-supplied checkpoint's `LATEST_FROZEN_BASELINE`. | RESOLVED by later freeze evidence. | RESOLVED |

No conflict was found that contradicts a frozen decision's actual *content* (lifecycle matrices, invariants, package boundaries) — all detected conflicts are freeze-status/commit-bookkeeping gaps caused by intermediate freeze-confirmation documents not being separately attached to this Claude Project.

---

## 15. Evidence and Source Index

| Source document | Information extracted |
| --- | --- |
| `README.md` | Platform purpose, explicit non-implementation boundary list |
| `pyproject.toml` | Python 3.13 requirement, dependency groups, tooling configuration |
| `MILESTONE_001_006_DOCUMENT_INTEGRATION_REVIEW.md` | M001–M006 decision-lineage matrix, architecture consistency audit |
| `MILESTONE_004_REPOSITORY_SCAFFOLDING_AND_TOOLCHAIN_BOOTSTRAP.md` | Scaffold contents, toolchain, Docker verification, freeze status |
| `MILESTONE_005_INFRASTRUCTURE_ARCHITECTURE.md` | Infrastructure layering, freeze status, revision history |
| `MILESTONE_006_FOUNDATION_CONTRACTS.md` | Foundation contracts (referenced; not deeply excerpted in this pass) |
| `MILESTONE_007_FIRST_INFRASTRUCTURE_IMPLEMENTATION_SLICE.md` | First infrastructure slice (referenced via M010 governing-documents table) |
| `MILESTONE_008_PERSISTENCE_CONNECTIVITY_FOUNDATION_SLICE.md` | PostgreSQL connectivity foundation (referenced via M010) |
| `MILESTONE_009_OBJECT_STORAGE_CONNECTIVITY_FOUNDATION_SLICE.md` | Object-storage connectivity foundation (referenced via M010) |
| `MILESTONE_010_SCOPE_SELECTION_AND_ARCHITECTURE_GAP_REVIEW.md` | Capability inventory, architecture gaps, M010 candidate selection |
| `MILESTONE_010_UNIFIED_INFRASTRUCTURE_RUNTIME_COMPOSITION.md` | `FoundationRuntime` design/implementation, test evidence |
| `MILESTONE_011_SCOPE_SELECTION_AND_ARCHITECTURE_GAP_REVIEW.md` | Selection of M012 domain-kernel design as next milestone |
| `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_DESIGN.md` | Aggregate roots, lifecycle states, Evidence/Criterion/Review model |
| `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_INDEPENDENT_REVIEW.md` | Independent review findings, score 67/100, REVISION REQUIRED |
| `MILESTONE_012_EXTERNAL_ARTIFACT_REGISTRATION_AND_BASELINE_RECONCILIATION.md` | External artifact registration, authority classification |
| `MILESTONE_012_AUTHORITY_AND_FREEZE_READINESS_CORRECTION.md` | Authority dependency matrix, freeze recommendation |
| `MILESTONE_013_DOMAIN_KERNEL_IMPLEMENTATION_SCOPE_SELECTION.md` | Scope selection for process-local primitives |
| `MILESTONE_013_PROCESS_LOCAL_DOMAIN_PRIMITIVE_FOUNDATION.md` | Frozen primitives, package placement |
| `MILESTONE_014_PROCESS_LOCAL_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` | Candidate scoring for first aggregate slice, invariant deferrals |
| `MILESTONE_014_PROCESS_LOCAL_EVIDENCE_PACKAGE_AGGREGATE_BEHAVIOR.md` | EvidencePackage aggregate design, tests, hostile review |
| `MILESTONE_015_PROCESS_LOCAL_REVIEW_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` | Review scope questions, risks, required design answers |
| `MILESTONE_015_PROCESS_LOCAL_REVIEW_AGGREGATE_BEHAVIOR.md` | Review aggregate design, hostile review, deferred items |
| `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_SCOPE_SELECTION.md` | Boundary questions, non-goals |
| `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_DECISION.md` | Package/dependency-direction decision, compatibility guarantees |
| `MILESTONE_017_PROCESS_LOCAL_RUN_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` | Run lifecycle matrix, manifest ownership rules |
| `MILESTONE_017_PROCESS_LOCAL_RUN_AGGREGATE_BEHAVIOR.md` | Run aggregate implementation, traceability table |
| `MILESTONE_018_PROCESS_LOCAL_CAMPAIGN_AGGREGATE_BEHAVIOR_SCOPE_SELECTION.md` | Campaign candidate comparison, dependency graph M012→M020 |
| `MILESTONE_018_PROCESS_LOCAL_CAMPAIGN_AGGREGATE_BEHAVIOR.md` | Campaign aggregate design, lifecycle/mutation matrices |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_SCOPE_SELECTION.md` | Reconstruction scope selection |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_DESIGN.md` | Reconstruction state records, validation rules, final freeze |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION_SCOPE_SELECTION.md` | Exact implementation scope, independent review findings |
| `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md` | Reconstruction implementation, files changed, error model |
| `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` | Repository/concurrency design questions, aggregate coverage |
| `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` | Repository contract design, version vocabulary, hostile self-review |

Not deeply excerpted in this pass (present in the project but only referenced indirectly above): `_editorconfig`, `alembic.ini`, `_dockerignore`, `_gitignore`. These are configuration files without milestone-narrative content relevant to this synthesis.

---

## 16. Continuation Instructions

For a future Claude session picking this project back up:

1. Read this master context first for orientation.
2. Read the exact active milestone documents in full before doing any M020 work: `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` and `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md`.
3. Verify repository truth (branch, HEAD commit, working-tree cleanliness, and the exact hashes in Section 10) against the **real** repository whenever real repository access (Claude Code, local Git) is available. Do not trust this document's hashes blindly.
4. Do not rely on this context for live Git state — it was assembled entirely from attached Markdown files in a chat/phone environment with no Git tool access.
5. Resume only from the current authorized mission: **M020 independent hostile review of the design in `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md`**, addressing the open questions in Section 11.
6. Stop on any contradiction or baseline mismatch and report it rather than silently resolving it — add it to a Conflict Register in whatever document you produce next.

---

## 17. Portable Work Rules

Any work produced without direct, authoritative repository access (i.e., anything produced in this chat/phone environment) must be labeled:

```text
PORTABLE DESIGN CANDIDATE
NOT INSTALLED
NOT VERIFIED AGAINST AUTHORITATIVE REPOSITORY
```

This applies to: scope documents, design documents, review reports, test matrices, and implementation plans produced away from the real repository.

Such portable work may **not** claim: executable validation, a real Git commit, implementation acceptance, or a milestone freeze. Only work done with real repository access (running `verify.ps1`/`security.ps1`, actual pytest/ruff/mypy/architecture-checker output, and a real `git commit`) may claim those things.

---

## 18. Final Checkpoint Block

```text
PROJECT=Empirical Trading Platform
LATEST_FROZEN_MILESTONE=MILESTONE-019
LATEST_FROZEN_BASELINE=22c064691564955b0a1f2a3e9cb6791b61dd8261
CURRENT_MILESTONE=MILESTONE-020
CURRENT_SCOPE_BASELINE=7d802bc57f085564f682017051f419d69552fb62
CURRENT_DESIGN_COMMIT=8dd31a6dc947048beb4fa7d273b0c3e8c31e0183
CURRENT_STATUS=DESIGN_READY_FOR_INDEPENDENT_REVIEW
CURRENT_MISSION=M020_INDEPENDENT_DESIGN_REVIEW
REPOSITORY_VERIFICATION_REQUIRED=true
M020_FROZEN=false
```

---

## Final Self-Review (Hostile Self-Review of This Master Context)

| ID | Severity | Finding | Correction | Disposition |
| --- | --- | --- | --- | --- |
| MASTER-ISSUE-0001 | MAJOR | This document was assembled via targeted keyword search over project files rather than a full sequential read of every byte of every milestone document, because of the very large combined size of the source set (≈800 KB across 33 documents). Some low-salience details (e.g., every individual hostile-review finding ID in every milestone) were therefore not transcribed. | Section 15 (Evidence and Source Index) explicitly lists which documents were deeply excerpted vs. only referenced, so a future reader knows where to go for full fidelity. Recommend a follow-up pass that opens each milestone document in full if perfect completeness is required. | ACCEPTED WITH DISCLOSURE |
| MASTER-ISSUE-0002 | MAJOR | Several milestone "final frozen" states (M015, M018, M019 at their own report time) were only confirmed as frozen indirectly, via a *later* document's baseline description, because the standalone freeze-confirmation reports were not separately present among the attached files. | Recorded explicitly as CONFLICT-0002–0004 in Section 14, each marked RESOLVED with the reasoning shown, rather than silently asserting freeze. | RESOLVED WITH DISCLOSURE |
| MASTER-ISSUE-0003 | MAJOR | The "M020 design commit awaiting independent review" hash (`8dd31a6dc947048beb4fa7d273b0c3e8c31e0183`) supplied in the operator's instructions does not appear verbatim in the retrieved document excerpts, which instead show a *baseline* hash (`7d802bc57f085564f682017051f419d69552fb62`) for the same document. | Both hashes are preserved exactly as given, the discrepancy is flagged in Section 10 and Section 14 (CONFLICT-0001), and it is left OPEN rather than silently resolved in either direction. | OPEN — requires real Git verification |
| MASTER-ISSUE-0004 | MINOR | M006 (Foundation Contracts) and M007–M009 (infrastructure implementation slices) were only searched briefly; their full detailed content (exact contract signatures, exact test evidence) is not reproduced in Section 9 beyond a status summary. | Flagged in Section 15 as "referenced" rather than "deeply excerpted"; does not affect the currently active M020 mission, which does not depend on M006–M009 internals beyond "frozen, no schema." | ACCEPTED WITH DISCLOSURE |
| MASTER-ISSUE-0005 | MINOR | No independent Git or filesystem verification of any commit hash, working-tree state, or test result was possible in this environment. | Explicitly stated in Document Control and repeated in Sections 10, 16, and 17. | ACCEPTED — inherent environment limitation |

No CRITICAL finding remains. Two MAJOR findings remain genuinely open pending real repository access (MASTER-ISSUE-0001 completeness and MASTER-ISSUE-0003 hash discrepancy); both are disclosed rather than silently resolved.

---

MASTER CONTEXT CONSOLIDATION COMPLETE
