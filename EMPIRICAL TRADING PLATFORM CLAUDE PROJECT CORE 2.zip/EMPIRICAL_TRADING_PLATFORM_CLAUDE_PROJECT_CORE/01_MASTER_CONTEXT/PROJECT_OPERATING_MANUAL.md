# Empirical Trading Platform — Project Operating Manual

## 1. Document Control

| Field | Value |
| --- | --- |
| Document name | PROJECT_OPERATING_MANUAL.md |
| Purpose | Defines **how** engineering work on the Empirical Trading Platform must be performed: how milestones are selected, designed, reviewed, implemented, verified, corrected, frozen, committed, and evidenced. |
| Intended users | Claude Code, ChatGPT (or any other model) acting as independent architecture reviewer, any future engineering agent, and the Project Owner. |
| Relationship to `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` | Complementary, not overlapping. MASTER_CONTEXT answers *what exists and where the project stands*. This manual answers *how work must be performed* to get from one state to the next. Neither document supersedes the other. |
| Source basis | (1) `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`; (2) active MILESTONE-020 scope/design documents; (3) frozen MILESTONE-019 design/implementation documents; (4) earlier milestone documents (M001–M018 and their scope-selection/independent-review companions); (5) `README.md`; (6) `pyproject.toml` and repository configuration files. |
| Authority limitations | **This operating manual defines the required engineering process. Frozen milestone documents and verified Git history remain authoritative for technical decisions and repository truth.** This manual cannot override a frozen milestone, cannot itself freeze anything, and cannot substitute for direct repository verification. |
| Update policy | Update only through a reviewed maintenance mission, the same way a milestone document would be corrected: propose the change, self-review it, and record it in a changelog/versioning entry below. Do not silently hand-edit process rules mid-mission. |
| Versioning policy | Version 1.0, generated 2026-07-23 from the attached Project Files as they existed at that time. Re-synthesize (not hand-patch) whenever the underlying milestone set materially changes the process it describes. |

---

## 2. Operating Roles

> Source note: the milestone documents themselves describe *mission types* (design, scope selection, implementation, independent review, correction) but do not name external tools such as "ChatGPT" or a "Project Owner." The role descriptions below are therefore classified as:
> **PROPOSED OPERATING RULE — REQUIRES REPOSITORY CONFIRMATION**, informed by (a) the mission-type conventions that *are* frozen throughout M004–M020, and (b) the operator's own description of the current multi-agent workflow in this conversation. Treat this section as a working convention until a maintenance mission confirms it against the real repository/team practice.

### Project Owner
- Approves strategic direction and which milestone family is pursued next when more than one legitimate candidate exists.
- Authorizes any scope expansion beyond what a scope-selection document already selected.
- Accepts or rejects a milestone's final freeze recommendation as the last human checkpoint.
- Does **not** need to make low-level technical decisions manually — those are delegated to the Design/Implementation/Review stages below, and are only escalated when a stop condition (Section 7) is hit.

### Claude Code
- Works **inside the authoritative repository** (currently `C:\Users\LuxSy\Documents\trading`, per milestone documents).
- Verifies Git state before any mission (Section 6).
- Reads frozen evidence (milestone documents) before writing or changing anything.
- Executes implementation strictly within an approved scope.
- Runs validation (Section 16) and reports exact, literal command output.
- Creates commits and external review packages (Section 21) when a mission calls for them.
- Stops immediately on any discrepancy (Section 7) rather than improvising a resolution.

### ChatGPT (or any other model acting in this capacity)
- Acts as an **independent architecture reviewer** and mission author, not as the implementer of record.
- Prepares mission prompts (Section 28) for Claude Code or for a portable/phone-based Claude session.
- Reviews Claude's completion reports for scope creep, unsupported assumptions, and missing evidence.
- Approves progression to the next stage **only from evidence** (literal test/validation output), never from a bare "done" claim.
- Does **not** claim repository verification without direct evidence — if it has no repository access in a given session, it must say so.

### Independent Review Agent
- Treats the design or implementation under review as **untrusted by default** — "assume it is wrong until proven correct" (Section 12).
- Reviews the exact diff, not a paraphrase of it.
- Records findings with severity (CRITICAL / MAJOR / MINOR / OBSERVATION).
- Performs the correction/freeze decision **separately** from whoever authored the design or implementation being reviewed.

### Role separation rule
One agent (e.g., a single Claude session) may perform more than one of the above roles **only when the mission explicitly authorizes it**. Even then, independent review must remain **logically separate**: a review step must re-derive its conclusions from the diff and frozen design, not simply restate the implementer's own self-review. Self-review (which every milestone document also performs, e.g. "Hostile Self-Review" sections) is a *complement* to independent review, not a substitute for it.

---

## 3. Mandatory Engineering Lifecycle

This exact sequence is frozen and is evidenced verbatim across every milestone document in the project:

```text
Design First -> Independent Review -> Correction Pass -> Freeze -> Scope Selection -> Implementation -> Hostile Review -> Verification -> Commit
```

### Design First
Before any code is written, the following must already be decided and documented: aggregate/contract shape, identity semantics, lifecycle/state matrices, version/sequence/history rules, error taxonomy, architecture placement, and explicit non-goals. A "design" mission produces a document, not code (see Section 9).

### Independent Review
The original designer or implementer cannot silently self-approve their own work. Every design/implementation milestone in this project has a **separate** independent-review pass (e.g., `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_INDEPENDENT_REVIEW.md` scored the M012 design 67/100 and required a correction pass before freeze). Independent review exists specifically to catch what the author's own hostile self-review missed.

### Correction Pass
Findings from independent review are corrected **without widening scope**. A correction pass may only: fix the specific finding, tighten a test, correct wording/section numbering, or narrow an over-broad claim. It may not introduce new features, new aggregates, new abstractions, or unrelated refactors (see Section 13).

### Freeze
"Frozen" means: the decision is now load-bearing for later milestones and may not be changed except through a new, separately reviewed correction mission. Freeze does **not** mean the platform is complete, that the design is bug-free forever, or that later evidence can never reopen it through a proper correction mission (see Section 14).

### Scope Selection
The next bounded milestone is selected from **repository evidence**, not from a wish list or roadmap aspiration. Candidates are compared on prerequisite readiness, architectural risk, and scope-creep risk, and exactly one bounded milestone is selected (see Section 8). Milestones M010 (scope selection), M011, M013, M014, M015, M016, M017, M018, M019, and M020 all follow this exact pattern in this project.

### Implementation
Implementation may change **only** what the frozen design and (if one exists) the frozen implementation-scope document authorize: the exact modules, exact names, and exact tests already specified. It may not choose architecture, invent a persistence detail, or silently generalize a contract (see Sections 10–11).

### Hostile Review
Implementation is treated as **wrong until proven correct**. The reviewer actively tries to find: scope creep, frozen-architecture violations, persistence/infrastructure leakage, cross-aggregate lookups, incorrect version/sequence/history behavior, mutable-collection exposure, and rejection-non-atomicity. This is evidenced by the "Hostile Review" / "Hostile Self-Review" table present in every implementation milestone document reviewed for MASTER_CONTEXT.

### Verification
Required **executable** evidence, not a description of intended tests: literal pytest pass/fail counts, coverage percentage, ruff/mypy output, architecture-checker pass/fail, negative-fixture pass/fail, security-scan output, and build/import checks (see Section 16).

### Commit
Committing is permitted only after scope was approved, (if required) design was independently reviewed, implementation matches the design, all required validation passed, no unresolved CRITICAL/MAJOR finding remains, and the working tree is otherwise clean of unrelated changes (see Section 15).

---

## 4. Milestone State Model

| Status | Meaning | Required evidence | Allowed next activity | Prohibited claims |
| --- | --- | --- | --- | --- |
| `SCOPE CANDIDATE SELECTED` | A scope-selection mission has picked exactly one bounded next milestone from repository evidence. | Baseline verification; candidate comparison; hostile self-review of the scope document itself. | Draft the design mission for that scope. | Cannot claim the design is approved, implemented, or frozen. |
| `SCOPE APPROVED FOR DESIGN` | The Project Owner (or equivalent authority) has accepted the selected scope as the authorized next design target. | Owner acknowledgment recorded. | Begin the design mission. | Cannot claim design content yet exists. |
| `DESIGN READY FOR INDEPENDENT REVIEW` | A design document is complete, internally hostile-self-reviewed, and not yet independently reviewed by a separate pass. | Design document with self-review section; acceptance-gate table all PASS. | Independent review mission. | Cannot claim `APPROVED AND FROZEN`; cannot be used to authorize implementation yet. |
| `DESIGN APPROVED AND FROZEN` | Independent review is complete, all CRITICAL/MAJOR findings resolved, and the design is now load-bearing. | Independent review report; correction commit(s) if any; clean re-validation. | Implementation-scope selection, or direct implementation if no separate implementation-scope mission is required. | Cannot claim implementation exists or was verified. |
| `IMPLEMENTATION SCOPE CANDIDATE SELECTED` | Exact modules/names/tests for implementing a frozen design have been selected. | Frozen design baseline cited; exact scope answers table. | Draft the implementation mission. | Cannot claim code exists. |
| `IMPLEMENTATION SCOPE APPROVED` | The implementation-scope document itself has been independently reviewed and accepted. | Implementation-scope independent review findings resolved. | Begin implementation mission. | Cannot claim implementation exists. |
| `IMPLEMENTATION ACCEPTED` | Code has been written and has passed its own hostile self-review and full validation, but has not yet had a **separate** independent freeze review. | Full validation output; hostile self-review table. | Independent freeze review. | Cannot claim `APPROVED AND FROZEN`. |
| `APPROVED AND FROZEN` | Independent freeze review is complete; all required validation passes; no unresolved CRITICAL/MAJOR finding remains; working tree is clean. | Independent review report; final validation run; commit SHA. | Downstream milestones may now depend on this baseline. | Cannot claim platform-wide completeness — freeze is scoped to this milestone only. |
| `NOT APPROVED` | Independent review found unresolved CRITICAL/MAJOR issues that a correction pass did not (or could not) resolve inside the current milestone's scope. | Issue register with open severities. | A **new**, separately scoped correction or redesign mission. | Cannot be cited as authority for any later milestone. |
| `BLOCKED` | Work cannot proceed because a genuine prerequisite is missing (e.g., a dependency milestone is not yet frozen). | Explicit statement of the missing prerequisite. | Wait for the prerequisite, or select a different bounded milestone. | Cannot claim partial progress as if it were the blocked milestone. |
| `STOPPED — REPOSITORY DISCREPANCY` | A Repository State Stop condition (Section 7) fired mid-mission. | Exact discrepancy description (expected vs. observed). | Report to Project Owner / next authority; do not self-resolve by reconciliation. | Cannot claim any work performed after the stop point is valid. |
| `PORTABLE DESIGN CANDIDATE` | Design-level work produced without authoritative repository access (e.g., in this chat/phone environment). | Explicit "not installed / not verified" labeling. | Return to the authoritative repository, verify baseline, and reconcile (Section 22). | Cannot claim Git verification, commit, or freeze. |
| `PORTABLE IMPLEMENTATION CANDIDATE` | Implementation-level work (code text) produced without authoritative repository access. | Same as above. | Same as above — must be installed and validated before it means anything. | Same as above. |

---

## 5. Baseline Discipline

| Term | Meaning |
| --- | --- |
| Frozen baseline | The commit hash of the repository state at the moment a milestone was declared `APPROVED AND FROZEN`. Downstream milestones cite this hash as "what existed before I started." |
| Scope baseline | The commit hash the repository was at when a scope-selection mission began its review (e.g., M020's scope-selection baseline `22c064691564955b0a1f2a3e9cb6791b61dd8261`). |
| Design baseline | The commit hash a design mission was written against (e.g., M020 design baseline `7d802bc57f085564f682017051f419d69552fb62`). |
| Implementation baseline | The commit hash an implementation mission started from, verified clean before any code was written (this is sometimes the same as the design's frozen baseline, sometimes a later one if intervening maintenance commits occurred). |
| Correction commit | A separate commit that resolves specific independent-review findings without widening the milestone's scope. |
| Final frozen baseline | The commit hash at which the milestone, including any correction commits, is declared `APPROVED AND FROZEN`. This becomes the *next* milestone's scope baseline. |

### Rules
- Verify `git rev-parse HEAD` before starting any mission.
- Verify the current branch.
- Verify the working tree is clean (`git status --short` empty).
- Inspect recent log (e.g., `git log -12 --oneline`) to confirm the expected milestone history is present.
- Verify expected files exist (the milestone documents and source files the mission depends on).
- Verify migration state (`migrations/versions` — expected to remain empty through at least MILESTONE-020, per every milestone document reviewed).
- **Stop on any mismatch.** Never continue by assumption.
- A later commit existing locally does **not** automatically authorize using it as the baseline: the mission must be re-scoped against the actual later state, because intervening commits may have changed facts the mission's scope document relied on. Silently adopting a newer HEAD without re-verifying scope is a Repository State Stop condition (Section 7), not a shortcut.

---

## 6. Repository Truth Protocol

Before every repository mission, require and record the literal output of:

```text
git rev-parse --show-toplevel
git rev-parse HEAD
git branch --show-current
git status --short
git status --short --branch
git log -12 --oneline
```

Add mission-specific checks such as:
- expected migrations state (`migrations/versions` empty, unless a mission is explicitly authorized to add a revision);
- expected package paths (e.g., confirming `src/empirical_platform/run/` exists before M018+ work that depends on it);
- expected document existence (the exact milestone documents the mission cites as authority);
- expected dependency state (`pyproject.toml` dependency groups match what the mission assumes).

### Prohibited reconciliation actions unless explicitly authorized by the Project Owner for a dedicated maintenance mission
- `git reset`
- `git rebase`
- `git checkout` of another baseline
- `git stash`
- `git commit --amend`
- deleting tracked work
- rewriting history
- modifying Git configuration
- changing line-ending policy

### Reporting drift
If the working tree is unexpectedly dirty, or HEAD does not match the expected baseline, the mission must **stop**, report the exact expected-vs-observed state, and wait for explicit authorization before touching anything. Do not "clean up" drift as a side effect of an unrelated mission.

---

## 7. Stop Conditions

| Category | Trigger examples | Must be reported | Must not be changed | Who must authorize continuation |
| --- | --- | --- | --- | --- |
| Repository State Stop | Wrong HEAD, wrong branch, dirty tree, unresolved lock file, missing expected baseline commit. | Exact expected vs. observed Git state. | Nothing — no reconciliation action from Section 6's prohibited list. | Project Owner, after manual repository inspection. |
| Document Conflict Stop | Two frozen documents contradict each other materially (see Conflict Register pattern, Section 31). | Both documents, the exact conflicting statements, and which (if any) later document supersedes. | Neither document is silently edited to resolve the conflict. | Project Owner / a dedicated reconciliation mission. |
| Scope Ambiguity Stop | Implementation would require inventing lifecycle, version, identity, error, or persistence semantics not already fixed by a frozen scope/design document. | The exact undecided question. | No silent invention of the missing rule. | A new, narrowly-scoped design mission answering exactly that question. |
| Architecture Boundary Stop | A required dependency direction (e.g., `campaign -> datasets`) is not authorized by `tools/check_architecture.py` or a frozen boundary decision like M016. | The exact forbidden import/direction needed. | No architecture-checker change without a separately reviewed boundary-decision mission (see M016 as the canonical pattern). | Project Owner / architecture boundary-decision mission. |
| Validation Stop | Tests, coverage, security scan, typing, formatting, or build fail; architecture checker fails. | Literal failing command and output. | No threshold weakened to force a pass. | Whoever owns the correction pass for that finding. |
| Environment Stop | Filesystem semantics, permissions, toolchain, Python version, or service (PostgreSQL/MinIO) connectivity prevent reliable work. | Exact environment symptom (e.g., broken unlink/delete semantics in a mounted folder — see Section 30's environmental note). | No forcing through an unreliable environment. | Whoever can switch to a reliable environment (e.g., local Claude Code on the authoritative host instead of a mounted/Cowork folder). |
| Security Stop | Secret exposure, unsafe dependency, credential leakage, or risk of a destructive operation. | Exact finding, redacted as needed. | No destructive cleanup performed automatically. | Project Owner, before any remediation. |

---

## 8. Scope Selection Procedure

1. Inspect frozen lineage (which milestones are `APPROVED AND FROZEN`).
2. Inventory current capabilities (what actually exists in source, not what a document merely intends).
3. Identify gaps — the first genuinely blocked capability.
4. Enumerate realistic candidates (typically 2–5, as seen in M010, M014, M018 scope-selection documents).
5. Compare candidates against the required dimensions (below).
6. Reject premature candidates explicitly, with a stated reason (do not just omit them).
7. Select exactly **one** bounded milestone.
8. Define non-goals for the selected milestone explicitly.
9. Perform a hostile self-review of the scope-selection document itself.
10. Validate that the change is documentation-only (no source, schema, or migration touched).
11. Commit only the scope document.

### Required candidate-comparison dimensions
- prerequisite readiness
- architecture risk
- implementation risk
- unsupported-assumption risk
- scope-creep risk
- reversibility
- reviewability
- future milestones unlocked
- schema/storage lock-in risk
- generic-abstraction risk (is a broad abstraction being reached for before evidence justifies it?)

---

## 9. Design Mission Procedure

A design mission must define:
- authoritative scope (cite the exact frozen scope-selection document);
- mandatory repository evidence reviewed;
- options evaluated, with strengths/risks for each (per the "Option / Strength / Risk / Decision" tables seen throughout M012, M019, M020);
- the selected decision;
- invariants;
- lifecycle/state matrices;
- identity semantics;
- version/sequence/history semantics;
- error model;
- architecture placement;
- compatibility guarantees with prior frozen milestones;
- deferred work;
- risks and mitigations;
- self-review;
- (separately) independent review;
- correction commit, if required;
- freeze gate / acceptance-gate table.

**A design must not contain hidden implementation.** If a design mission finds itself writing runnable code, it has silently become an implementation mission and must stop and be re-scoped.

---

## 10. Implementation Scope Procedure

A separate implementation-scope mission is required whenever the frozen design contains material choices still left to a "mechanical code-placement" level (this pattern is explicit in M015 §17 and M019's implementation-scope document). The scope must define:
- exact modules;
- exact public/internal names (e.g., `_reconstruction.py`, `_reconstruct_*`);
- allowed source changes;
- prohibited source changes;
- architecture-checker changes, if any, and their justification;
- tests required;
- error types;
- compatibility guarantees;
- validation required;
- commit boundary (which files may be staged);
- hostile-review focus for the *implementation* that will follow.

**Implementation must not choose architecture silently.** If an implementer discovers the frozen design left an architectural question open, that is a Scope Ambiguity Stop (Section 7), not a decision for the implementer to make quietly.

---

## 11. Implementation Procedure

1. Baseline verification (Section 6).
2. Complete repository inspection relevant to the change.
3. Compatibility plan against existing frozen behavior.
4. Smallest bounded implementation that satisfies the frozen (implementation-)scope document.
5. Focused tests for the new behavior.
6. Full validation (Section 16).
7. Hostile self-review.
8. Correction pass for anything the self-review found.
9. Exact diff inspection before staging.
10. Stage only authorized files.
11. Commit.
12. Post-commit verification (re-run validation against the committed state, not just the working tree).
13. Independent freeze review (a separate mission/session).

### Rules
- no unrelated refactoring;
- no new features beyond the authorized scope;
- no frozen primitive redesign;
- no speculative abstraction;
- no broad architecture permission granted "while we're at it";
- no weakened tests or coverage thresholds;
- no ignored warnings without an explicit classification (e.g., "false positive" with rationale, as seen in M004's secret-scan maintenance revision).

---

## 12. Independent Review Procedure

The independent reviewer must:
- verify the baseline the design/implementation claims to be built on;
- inspect the exact diff, not a summary of it;
- inspect directly and transitively relevant source (frozen primitives the change depends on, not just the new files);
- compare against the frozen design line by line;
- **assume the implementation is wrong** until each claim is independently confirmed;
- test both valid and invalid paths;
- verify atomicity (rejected operations leave no partial state change);
- verify architecture (no forbidden import direction, no persistence/infrastructure leakage);
- verify evidence accuracy (do the reported test counts/coverage actually match what was run?);
- classify findings by severity;
- apply only narrow corrections in response;
- create a **separate** correction commit;
- rerun all validation after correction;
- decide freeze.

### Severity levels
| Severity | Definition | Blocks freeze? |
| --- | --- | --- |
| CRITICAL | Violates a frozen invariant, introduces a security/data-integrity risk, or falsifies evidence. | Yes — always. |
| MAJOR | Material gap in correctness, architecture compliance, or test coverage that could mislead a future consumer of this milestone. | Yes, until resolved. |
| MINOR | Small correctness or clarity gap that does not threaten the milestone's core guarantees. | Should be resolved before freeze, but the Project Owner may explicitly accept a MINOR finding with disposition recorded, if truly non-blocking. |
| OBSERVATION | Non-blocking note for future consideration (style, naming, potential future risk). | No. |

---

## 13. Correction Pass Rules

Corrections must:
- stay inside the current milestone's approved scope;
- address only confirmed findings (not introduce new "while I'm here" improvements);
- preserve baseline lineage (do not rewrite history to hide what was corrected);
- use a **separate** commit from the original implementation/review commit;
- update reports and issue registers with exact disposition ("Resolved", "Not Applicable", etc.);
- rerun full validation;
- repeat hostile review of the corrected state, not just the delta.

**Prohibit amending the original implementation/review commit** unless explicitly authorized for a specific, narrow reason (e.g., a same-day typo fix before any downstream milestone has cited the commit) — and even then, record that an amend occurred.

---

## 14. Freeze Rules

A milestone may be frozen only when:
- scope was approved;
- design was independently reviewed, when a design stage was required;
- implementation matches the design (no undocumented divergence);
- all required tests pass;
- the architecture checker passes, including negative fixtures;
- the security scan passes;
- typing/lint/format/build all pass;
- no unresolved CRITICAL or MAJOR finding remains;
- the reported evidence is accurate (spot-checkable against literal command output);
- the working tree is clean;
- an external review package exists, when the mission mandates one (Section 21).

### What "frozen" means
- Decisions cannot be changed casually — only through a new, separately reviewed correction/redesign mission.
- Later milestones may depend on this baseline as ground truth.
- Corrections require a new reviewed mission, not a quiet edit.

### What "frozen" does **not** mean
- It is **not** a claim that the entire platform is complete, secure for production, or free of undiscovered bugs.
- It is **not** authorization for any deferred/roadmap item merely because that item is mentioned as "future work" in the frozen document.

---

## 15. Git and Commit Rules

- One mission produces one bounded commit, or an explicit correction chain of clearly-labeled commits (never an ambiguous mixture).
- Commit messages are repository-consistent (imperative, milestone-referencing, e.g. "Harden MILESTONE-014 evidence package aggregate behavior" as seen in the M014→M015 baseline chain).
- No unrelated files staged.
- Run `git diff --check` before committing (whitespace/conflict-marker hygiene).
- Confirm a final clean tree after commit.
- Record the starting baseline and the final HEAD explicitly in the mission report.
- **Never fabricate a commit hash.** If a mission is running in a portable/no-repository-access environment, it must not present any string as if it were a real commit hash produced by that environment (see Section 22 and MASTER-ISSUE-0003 in the Master Context's own self-review as a cautionary example of exactly this ambiguity).
- No empty commits unless explicitly required by a specific mission (e.g., a deliberate checkpoint marker).
- No amend of already-reviewed commits (see Section 13).
- No force-push or history rewrite.

---

## 16. Validation Standard

Canonical validation categories, evidenced across essentially every implementation milestone in this project:
- Python version check (project requires `>=3.13,<3.14`);
- security scan (`detect-secrets`-based, per `scripts/security.ps1`);
- dependency audit (`pip-audit`);
- focused unit tests (the specific new test file, run with `--no-cov` to avoid tripping the global coverage gate on a partial run);
- full test suite (`pytest`, via `verify.ps1`);
- coverage (project threshold currently `fail_under = 80` per `pyproject.toml`; recent milestones have reported coverage in the 90%+ range);
- formatting (`ruff format --check`);
- lint (`ruff check`);
- mypy / type checking (strict mode);
- architecture checker (`tools/check_architecture.py`);
- negative fixtures (`tests/fixtures/illegal_imports/...`, proving forbidden imports are actually detected);
- build/import/version checks (`python -m build`, `import empirical_platform; print(__version__)`);
- database connectivity, where relevant (PostgreSQL, via Docker Compose, for M008/M010-class work);
- object-storage connectivity, where relevant (MinIO, via Docker Compose, for M009/M010-class work);
- migration checks, where relevant (`migrations/versions` must remain empty unless a mission is explicitly authorized to add a revision);
- `git diff --check`;
- final `git status --short` (must be clean).

**Exact commands come from the repository and the current mission** (e.g., `scripts/verify.ps1`, `scripts/security.ps1`, `scripts/local-infra.ps1`), not from this document alone — this manual describes *categories*, not a frozen literal command list, since scripts may evolve.

**No threshold may be weakened to make a mission pass.** If a mission cannot pass validation as currently defined, that is a Validation Stop (Section 7), not a license to lower the bar.

---

## 17. Test Design Rules

Required test categories, where applicable to the aggregate/contract under test:
- construction (identity, initial state, initial version/sequence, empty collections);
- valid behavior (each allowed lifecycle transition/operation);
- invalid behavior (each disallowed transition/operation is rejected);
- lifecycle matrices (every from-state/operation pair, not just the happy path);
- version effects (does the operation increment `AggregateVersion` exactly once, or not at all?);
- sequence effects (does the operation advance `TransitionSequence`, or not?);
- history effects (does the operation append a `StateTransitionRecord`, or not?);
- collection ordering (supplied order preserved exactly);
- duplicate rules (per the exact per-aggregate duplicate policy — see Section 7 of the Master Context for the concrete rules per collection);
- terminal states (all mutation attempts on a terminal aggregate are rejected);
- rejection atomicity (snapshot-and-compare across every rejected path);
- continued behavior after reconstruction (an aggregate rebuilt via `_reconstruct_*` behaves identically to one built through normal construction, for any subsequent valid operation);
- public API/export boundaries (nothing internal is accidentally exported);
- architecture violations (negative fixtures actually fail as expected);
- no external side effects (no accidental I/O, persistence, or network calls from a "process-local" test);
- concurrency conflicts (for repository-layer work once it exists — e.g., `OptimisticConcurrencyConflict` on a stale `save`);
- idempotency (repeated identical operations behave deterministically, e.g., an unchanged `save`);
- malformed persisted state (every reconstruction error category has at least one test proving it is actually raised).

**Tests must prove contracts, not incidental implementation details** — e.g., do not assert on private field names when a public property exists; do assert on private fields only where no public property exists and reconstruction-specific verification requires it (this exact caveat appears in M019's design self-review).

---

## 18. Architecture Rules

- Domain packages do not import infrastructure (persistence, object storage, SQLAlchemy, psycopg, boto3/botocore).
- Persistence does not leak into aggregates (no ORM types, no SQL, no schema assumptions inside `campaign`, `run`, `evidence`, `review`).
- Internal reconstruction APIs (`_reconstruction` modules, `_reconstruct_*` factories) remain private/package-internal, never publicly exported.
- Package boundaries are explicit and enforced mechanically by `tools/check_architecture.py`, not by convention alone.
- New dependency directions require a reviewed authorization (the M016 pattern: a dedicated architecture-boundary-decision milestone, not an ad hoc import).
- Architecture-checker changes need accompanying negative fixtures proving the new rule actually rejects a violation.
- No generic abstraction "by habit" — M020 explicitly rejected a generic `Repository[Identity, Aggregate]` in favor of aggregate-specific contracts, precisely to avoid this failure mode.
- No cyclic imports.
- Public exports are intentional (an explicit `__init__.py` export list, not "whatever happens to be importable").
- Shared modules (`shared.domain`, `shared.persistence`, etc.) contain only genuinely shared behavior — aggregate-specific lifecycle matrices, terminal metadata, and duplicate rules stay in their own aggregate package, per M019's explicit shared/aggregate-specific helper boundary.

---

## 19. Persistence Evolution Rules

Required ordering for all future repository/mapping/schema work (this exact ordering is the actual lineage of M012→M020 in this project, not a hypothetical):

1. Aggregate behavior frozen (M013–M018).
2. Reconstruction frozen (M019).
3. Repository/concurrency contract frozen (M020, currently in progress — design not yet frozen).
4. Repository contract source implementation.
5. Persistence mapping design.
6. Schema/migration design.
7. Repository implementation.
8. Transaction integration (Unit of Work).
9. Application services.

### Standing rules
- Schema must not dictate domain semantics — the domain model was frozen *before* any schema work began, deliberately, to avoid this.
- Repositories must not increment domain versions — `AggregateVersion` is a domain-owned concept; `save`/`add` persist it, they do not compute or mutate it (per M020 design §17: "repository save never increments aggregate version").
- Optimistic concurrency must prevent blind overwrite — every `save` must compare an explicit `expected_persisted_version` before writing.
- Root and owned state (owned collections, transition history) must persist atomically for one aggregate `save`/`add` call.
- Mapping must preserve order, identity, version, sequence, history, and terminal metadata exactly — no reconstruction path may normalize, sort, merge, deduplicate, overwrite, or silently discard collection elements (M019 §19).
- SQL/ORM types must never enter domain contracts (aggregates or their public repository interfaces).

---

## 20. Evidence Standard

Every completion report must distinguish, as applicable:
- command executed (literal);
- exact result (literal output, not a paraphrase);
- tests passed/skipped, with totals (e.g., "119 passed, 9 skipped", not "tests passed");
- coverage (exact percentage);
- warnings (and their disposition — fixed, or classified as an accepted false positive with rationale);
- files changed (exact list, created vs. modified);
- commit SHA;
- working-tree state (clean/dirty, with detail if dirty);
- unresolved issues (explicit, with severity);
- environment limitations (e.g., no real Git access in this session).

**Do not accept "tests passed" without totals when totals are available** — every implementation milestone reviewed for the Master Context reported literal pass/skip/coverage numbers; this is the evidentiary bar for this project, not an optional nicety.

**Do not claim evidence from a non-authoritative environment.** A chat/phone session with no Git tool access must say so plainly rather than presenting inferred or assumed results as if they were run.

---

## 21. External Review Package Standard

> Source note: the concept of an "external review package" is explicitly referenced as required evidence in multiple milestone documents (e.g., MASTER_CONTEXT Section 14 notes M019's implementation scope selection cites "External review package evidence"). The **exact folder/file structure below**, however, was not found verbatim inside the retrieved milestone document text in this environment. It is therefore classified as:
> **PROPOSED OPERATING RULE — REQUIRES REPOSITORY CONFIRMATION.** Adopt it as the standard going forward, but confirm/align it against whatever the real repository's actual `external-review/` history (if any) already looks like the next time authoritative repository access is available.

Mandatory structure:

```text
external-review/<PHASE_OR_MISSION_NAME>/
    repository-truth.txt
    complete.diff
    source/
    tests/
    database/           (when relevant)
    architecture/
    evidence/
    review-instructions.md
    sha256-manifest.txt
external-review/<PHASE_OR_MISSION_NAME>.zip
```

- **`repository-truth.txt`** — `git status`, `git status --short`, branch, HEAD, `git log`, `git diff --check`, `git diff --stat`, `git diff --name-status`, baseline and final HEAD.
- **`complete.diff`** — exact diff from the frozen baseline to the final HEAD.
- **`source/`** — changed source files; directly relevant source files; transitively relevant contracts/primitives; configuration and safety files.
- **`tests/`** — changed tests; directly relevant tests; architecture tests; negative fixtures.
- **`database/`** — when relevant: migrations, schema evidence, migration status, persistence contracts.
- **`architecture/`** — checker, boundary rules, dependency evidence.
- **`evidence/`** — validation outputs: security, tests, coverage, typing, lint/format, build, service-integration evidence.
- **`review-instructions.md`** — what to review, baseline, final HEAD, scope, non-goals, known warnings, hostile-review questions.
- **`sha256-manifest.txt`** — manifest for all packaged files except itself where appropriate.

### ZIP requirements
- ZIP opens without error;
- entry count matches expectation;
- manifest matches the ZIP contents;
- no unrelated files included;
- no secrets included;
- package creation does not modify source;
- ZIP SHA-256 is reported.

### Optional portable artifacts (for transporting work across environments)
- `mission.patch`
- `repository.bundle`
- `apply-instructions.md`
- `mission-result.json`

---

## 22. Portable Work Rules

When no authoritative repository exists in the current session (e.g., this chat/phone environment), label the work:

```text
PORTABLE DESIGN CANDIDATE
NOT INSTALLED
NOT VERIFIED AGAINST AUTHORITATIVE REPOSITORY
```

Portable work may include: architecture analysis, scope candidates, design candidates, review reports, test matrices, implementation plans, documentation.

Portable work may **not** claim: Git verification, a real commit, executable validation, implementation acceptance, or freeze.

### When returning to the authoritative repository
1. Verify baseline (Section 6).
2. Compare the portable work against current source — has anything changed underneath it?
3. Resolve any conflicts explicitly (do not silently merge).
4. Install changes surgically (only the files the portable work actually specified).
5. Run all validation (Section 16).
6. Perform hostile review (Section 12).
7. Commit (Section 15).
8. Freeze only after evidence (Section 14) — a portable candidate does not inherit freeze status just by being installed.

---

## 23. File and Line-Ending Safety

- Do not normalize unrelated files as a side effect of an unrelated milestone.
- Do not change line endings as part of unrelated work.
- CRLF/LF-only drift is itself a repository-state discrepancy (Section 7's Repository State Stop), not a cosmetic issue to silently fix.
- Do not introduce `.gitattributes` or Git configuration changes without a separate, reviewed maintenance mission.
- Stop on lock files or filesystem semantics that make Git unreliable.
- Do not continue through a mounted filesystem that cannot reliably delete/rename files (see the environmental note in Section 30 — this is a known, currently-active condition for the Cowork/mounted-folder environment, not a hypothetical).
- Repository integrity must be re-verified after any environmental failure, before trusting the working tree again.

---

## 24. Security Rules

- No credentials in source or in any evidence/review package.
- No private keys.
- No tokens.
- No unredacted environment files (`.env`, as opposed to `.env.example`).
- No secret-bearing logs.
- Dependency audit required (`pip-audit`).
- Secret scan required (`detect-secrets`-based, repository-driven target discovery per the M004 maintenance revision).
- Least-privilege operations.
- No destructive commands without explicit authorization.
- No database/object-storage mutation outside authorized tests (e.g., disposable Docker Compose projects for integration tests, torn down with `docker compose down -v --remove-orphans`, as seen in M010's integration-test evidence).
- No dangerous automatic cleanup performed without being explicitly part of the mission's authorized steps.

---

## 25. Documentation Rules

- Architecture, code, milestone documents, reports, and implementation artifacts are written in **English**.
- User conversation may be in **Arabic** (or any language the Project Owner uses) — this does not change the documentation-language rule above.
- Every document has a Document Control section.
- Every design records non-goals.
- Every review records findings.
- Every correction records dispositions.
- Every milestone records its baseline and final decision.
- Do not mark future/deferred work as authorized merely because it appears in a roadmap section — a roadmap entry is a plan, not an authorization.
- Do not silently remove historical documents from the **repository** (removing a document from the *Claude Project's active file set* to save context, per Section 27, is a different, permitted action — the repository copy is what must be preserved).
- Consolidated documents (this manual, and `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`) are navigation aids, not replacements for frozen source documents.

---

## 26. Project Knowledge Management

| Artifact | Answers |
| --- | --- |
| `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` | "What exists, and where are we right now?" |
| `PROJECT_OPERATING_MANUAL.md` (this document) | "How must work be performed to get from here to the next state?" |
| Frozen milestone documents | Decision authority — the actual content of what was decided. |
| Active milestone documents (currently M020's scope + design) | What governs the *current* mission. |
| Repository source/tests | Live implementation truth — what the code actually does right now. |
| External review packages (Section 21) | Independent review evidence — what a reviewer actually saw and checked. |

### Rules
- `MASTER_CONTEXT` answers "what exists and where we are."
- `OPERATING_MANUAL` answers "how work must be performed."
- Frozen milestone documents remain decision authority; neither consolidated document overrides them.
- Active milestone documents govern current work.
- Git/source/tests provide live implementation truth and take precedence over any document if the two ever disagree (that disagreement itself should be raised as a Document Conflict Stop, Section 7).
- External packages provide independent review evidence.
- The Claude Project may use a reduced active file set for context efficiency, but the **repository** must retain every historical milestone document regardless of what is active in the Claude Project.

---

## 27. Claude Project File Strategy

Recommended active Claude Project file set:

```text
EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md
PROJECT_OPERATING_MANUAL.md
README.md
pyproject.toml
MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_DESIGN.md
MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md
MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md
MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md
```

Older milestone files (M001–M018 and their scope-selection/independent-review companions) may be removed from the Claude Project's active file set to reduce context usage, **but must not be deleted from the real repository.** They remain the decision authority MASTER_CONTEXT's Milestone Lineage table (Section 5) points back to.

---

## 28. Mission Prompt Requirements

Every mission prompt (whether for Claude Code, a portable Claude session, or ChatGPT acting as reviewer) must include:
- mission title;
- authoritative baseline (exact commit hash expected);
- expected branch;
- expected clean-tree state;
- required documents (which milestone documents the mission must read first);
- exact objective;
- allowed files (which files/paths the mission may touch);
- prohibited files;
- scope boundary (explicit non-goals);
- stop conditions (which of Section 7's categories apply and how);
- validation (which of Section 16's categories apply for this mission);
- hostile review (what the reviewer of *this* mission's output should specifically look for);
- correction policy (how findings from this mission will be corrected, per Section 13);
- commit gate (exact conditions under which this mission's output may be committed, per Section 15);
- external review package requirements, where applicable (Section 21);
- mandatory report structure (Section 29);
- exact final decision phrase expected (e.g., "SCOPE CANDIDATE SELECTED", "APPROVED AND FROZEN").

---

## 29. Mandatory Final Report Format

Every mission report should contain, as applicable:

```text
A. Baseline Verification
B. Evidence Reviewed
C. Scope Interpretation
D. Files Changed
E. Design/Implementation Details
F. Invariant or Contract Tables
G. Tests
H. Validation
I. Findings
J. Corrections
K. Architecture Compliance
L. Commit Evidence
M. External Review Package
N. Final Decision
```

The exact report may be extended per mission (as every milestone document in this project in fact does, often to 20–35 sections) but should not **omit** material evidence for the sake of brevity.

---

## 30. Current Project Checkpoint

```text
PROJECT=Empirical Trading Platform
LATEST_FROZEN_MILESTONE=MILESTONE-019
LATEST_FROZEN_BASELINE=22c064691564955b0a1f2a3e9cb6791b61dd8261
CURRENT_MILESTONE=MILESTONE-020
CURRENT_SCOPE_BASELINE=7d802bc57f085564f682017051f419d69552fb62
CURRENT_DESIGN_COMMIT=8dd31a6dc947048beb4fa7d273b0c3e8c31e0183
CURRENT_STATUS=DESIGN_READY_FOR_INDEPENDENT_REVIEW
CURRENT_MISSION=M020_INDEPENDENT_DESIGN_REVIEW
REPOSITORY_VERIFICATION_REQUIRED=true
M020_FROZEN=false
```

Also record:
- The current Project/Cowork mounted-folder environment has demonstrated broken unlink/delete semantics.
- Do **not** use that mounted environment for authoritative Git mutation until the environment is repaired.
- Use local Claude Code on the Windows host (`C:\Users\LuxSy\Documents\trading`) for repository mutations and commits.
- This environmental note does not change the milestone baseline above.

> Consistency note: as flagged in `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` (Section 10 / CONFLICT-0001), the `CURRENT_DESIGN_COMMIT` hash above was supplied by the operator and was **not** found verbatim inside the retrieved `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` text in this environment (which instead states its own baseline as `7d802bc57f085564f682017051f419d69552fb62` and explicitly says it is not committed). This checkpoint block is reproduced here **exactly as given**, per instruction not to silently alter checkpoint values, but the discrepancy remains OPEN and must be resolved against real Git history before being treated as fact.

---

## 31. Conflict Register

| ID | Documents | Conflict | Authority evidence | Resolution | Status |
| --- | --- | --- | --- | --- | --- |
| MANUAL-CONFLICT-0001 | This checkpoint block (Section 30) vs. `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` retrieved text | Checkpoint asserts a "current design commit" of `8dd31a6dc947048beb4fa7d273b0c3e8c31e0183`; the design document's own text states its baseline as `7d802bc57f085564f682017051f419d69552fb62` and says it is not staged/committed. | Neither hash was independently re-derived from live Git in this environment. | Same as `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` CONFLICT-0001 — reproduced here for the manual's own checkpoint section rather than silently picking one value. | OPEN — requires real Git verification |
| MANUAL-CONFLICT-0002 | Section 2 (Operating Roles) vs. milestone document source material | Milestone documents never name "ChatGPT" or a "Project Owner" as formal roles; those names come from the operator's description of the current workflow, not from repository evidence. | No milestone document defines these role names. | Classified explicitly as `PROPOSED OPERATING RULE — REQUIRES REPOSITORY CONFIRMATION` at the top of Section 2, rather than presented as if it were already frozen project policy. | INSUFFICIENT SOURCE EVIDENCE — treat as convention pending confirmation |
| MANUAL-CONFLICT-0003 | Section 21 (External Review Package Standard) vs. milestone document source material | Milestone documents reference "external review package" as a concept/evidence artifact but the exact folder structure (`repository-truth.txt`, `complete.diff`, `sha256-manifest.txt`, etc.) was not found verbatim in the retrieved excerpts. | General concept is evidenced; exact structure is not. | Flagged explicitly at the top of Section 21 as `PROPOSED OPERATING RULE — REQUIRES REPOSITORY CONFIRMATION`. | INSUFFICIENT SOURCE EVIDENCE — adopt as standard, confirm against real repository history when available |

No conflict was found that contradicts the actual *content* of any frozen technical decision (lifecycle matrices, invariants, package boundaries, or the M020 design's technical content) — every conflict above is a process-role or checkpoint-provenance question, not a technical one.

---

## 32. Hostile Self-Review

| ID | Severity | Finding | Evidence | Correction | Disposition |
| --- | --- | --- | --- | --- | --- |
| MANUAL-ISSUE-0001 | MAJOR | Section 2 (Operating Roles) risked presenting an invented, unsupported process (naming "ChatGPT" and "Project Owner" as formal roles) as if it were already frozen project policy. | No milestone document mentions these role names; they come only from the operator's description of the current multi-agent workflow. | Added an explicit `PROPOSED OPERATING RULE — REQUIRES REPOSITORY CONFIRMATION` classification at the top of Section 2, and cross-referenced it in the Conflict Register (MANUAL-CONFLICT-0002). | RESOLVED WITH DISCLOSURE |
| MANUAL-ISSUE-0002 | MAJOR | Section 21's exact external-review-package folder structure was drafted from the operator's instruction text rather than confirmed against retrieved milestone document content, risking an over-specific "invented rule" being presented as settled project standard. | A targeted search of project files did not surface the literal folder/file names inside milestone document text. | Classified explicitly as `PROPOSED OPERATING RULE — REQUIRES REPOSITORY CONFIRMATION` at the top of Section 21, cross-referenced in the Conflict Register (MANUAL-CONFLICT-0003). | RESOLVED WITH DISCLOSURE |
| MANUAL-ISSUE-0003 | MAJOR | The checkpoint block (Section 30) reproduces `CURRENT_DESIGN_COMMIT=8dd31a6dc947048beb4fa7d273b0c3e8c31e0183`, a hash not found verbatim in the retrieved design document, risking the appearance of independently-verified Git truth. | Same discrepancy already identified and left OPEN in `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`. | Reproduced the checkpoint exactly as instructed (do not silently alter checkpoint values) but added an explicit consistency note directly beneath it, and logged MANUAL-CONFLICT-0001. | OPEN — requires real Git verification, not resolved by this document |
| MANUAL-ISSUE-0004 | MINOR | This manual could be read as implying it has the authority to change frozen technical decisions, since it discusses freeze/correction process in detail. | Risk is inherent to writing a process document alongside a technical-decision document. | Document Control (Section 1) and the freeze rules (Section 14) both explicitly state frozen milestone documents and Git history remain authoritative for technical decisions; this manual only ever governs *process*. | RESOLVED |
| MANUAL-ISSUE-0005 | MINOR | Risk that a single agent could use ambiguity in Section 2's role-separation rule to self-authorize both implementation and its own independent review. | The role-separation paragraph as originally drafted stated multi-role use is "allowed when authorized" without repeating the independence requirement strongly enough. | Added an explicit sentence requiring independent review to "re-derive its conclusions from the diff and frozen design, not simply restate the implementer's own self-review," even when performed by the same agent in a different pass. | RESOLVED |
| MANUAL-ISSUE-0006 | OBSERVATION | This manual, like the Master Context, was assembled without full byte-for-byte reading of all 20 milestone documents' 800 KB combined text, relying instead on targeted retrieval plus the deep familiarity already built while producing `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` in this same session. | Some very granular per-milestone phrasing may not be reproduced verbatim. | No correction applied — flagged for transparency only, consistent with MASTER-ISSUE-0001 in the Master Context's own self-review. | ACCEPTED WITH DISCLOSURE |

No CRITICAL finding was identified. Three MAJOR findings were resolved by explicit disclosure/classification rather than by silently presenting unsupported content as settled fact; one of those three (MANUAL-ISSUE-0003 / MANUAL-CONFLICT-0001) remains genuinely OPEN pending real Git verification and is not falsely marked resolved.

---

## 33. Final Operating Rules Block

```text
OPERATING_MODEL=DESIGN_REVIEW_CORRECTION_FREEZE_SCOPE_IMPLEMENT_REVIEW_VERIFY_COMMIT
QUALITY_PRIORITY=CORRECTNESS_OVER_SPEED
FROZEN_DECISIONS_MUTABLE=false
SCOPE_CREEP_ALLOWED=false
REPOSITORY_TRUTH_REQUIRED=true
EXECUTABLE_EVIDENCE_REQUIRED=true
INDEPENDENT_REVIEW_REQUIRED=true
CORRECTION_COMMIT_SEPARATE=true
EXTERNAL_REVIEW_PACKAGE_REQUIRED_WHEN_MANDATED=true
PORTABLE_WORK_CAN_FREEZE=false
CURRENT_MISSION=M020_INDEPENDENT_DESIGN_REVIEW
```

---

PROJECT OPERATING MANUAL CONSOLIDATION COMPLETE
