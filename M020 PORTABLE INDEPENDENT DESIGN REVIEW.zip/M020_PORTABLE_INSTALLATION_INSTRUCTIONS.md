# M020 Portable Review — Repository Installation Instructions

These instructions are for a **local Claude Code session with live access** to the authoritative repository at `C:\Users\LuxSy\Documents\trading`. Nothing in this file has been executed. No step below has been performed in the portable (chat) environment that produced this package.

## 0. Preconditions

Do not begin installation unless all of the following are true:
- You are running inside Claude Code (or an equivalent agent) with real shell/Git access to `C:\Users\LuxSy\Documents\trading`.
- You have read `PROJECT_OPERATING_MANUAL.md` §5 (Baseline Discipline), §6 (Repository Truth Protocol), and §13 (Correction Pass Rules) before proceeding.
- You have this portable package's three documents available: the corrected design candidate, the independent review report, and this instructions file.

## 1. Verify Live Repository State

Run and record the literal output of:

```text
git rev-parse --show-toplevel
git rev-parse HEAD
git branch --show-current
git status --short
git status --short --branch
git log -12 --oneline
```

Required checks:

- **Branch must be `master`.**
- **Working tree must be clean** (`git status --short` empty).
- **`migrations/versions` must remain empty** (`git ls-files migrations/versions` should return nothing, or only an `.gitkeep`-style placeholder if one exists — confirm no real migration revision is present).

## 2. Verify HEAD Against the Expected Design Commit

The portable package's checkpoint asserts:

```text
EXPECTED_DESIGN_COMMIT=8dd31a6dc947048beb4fa7d273b0c3e8c31e0183
```

This hash was **never verified** in the portable environment — it was operator-supplied and is explicitly flagged as an open discrepancy in `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` (Conflict CONFLICT-0001) and `PROJECT_OPERATING_MANUAL.md` (MANUAL-CONFLICT-0001), because the retrieved `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` text instead states its own baseline as `7d802bc57f085564f682017051f419d69552fb62`.

**Do the following, in order, and stop if any check fails:**

1. Compare live `git rev-parse HEAD` against `8dd31a6dc947048beb4fa7d273b0c3e8c31e0183`.
   - If it matches: proceed, and record in your mission report that this hash is now **confirmed**, resolving CONFLICT-0001/MANUAL-CONFLICT-0001 as `RESOLVED` with this commit as evidence.
   - If it does not match: **do not proceed by assumption.** Instead, compare live HEAD against `7d802bc57f085564f682017051f419d69552fb62` (the design document's own stated baseline).
     - If HEAD equals that hash instead: proceed, but record explicitly that `CURRENT_DESIGN_COMMIT` in the operating manual/master context was **incorrect** as asserted and must be corrected to the design's own stated baseline value in a documentation maintenance pass.
     - If HEAD equals **neither** hash: this is a **Repository State Stop** (`PROJECT_OPERATING_MANUAL.md` §7). Report the exact expected-vs-observed mismatch and stop. Do not install this correction against an unverified baseline.
2. Confirm the file `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` exists in the repository and its content matches (byte-for-byte, or materially) what was reviewed in the portable environment (reproduced in full inside the corrected design candidate's "Unchanged" sections, for cross-checking).

## 3. Compare Portable Correction Against Live Document

Do **not** overwrite the live design document blindly. Instead:

1. Open the live `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md`.
2. Open `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN_PORTABLE_CORRECTION.md` from this package.
3. Diff them conceptually, section by section (the corrected candidate marks every changed/new section with **[CORRECTED]** or **[NEW]** in its heading — every other section is intended to be materially identical to the live document).
4. If the live document has changed since the portable review's baseline (i.e., someone else committed a design change in the meantime), **resolve the conflict explicitly** — do not silently prefer either version. Identify exactly which sections diverge, determine whether the live change or the portable correction (or both) remain valid, and produce a reconciled section. This is a Document Conflict Stop scenario if the divergence is material (`PROJECT_OPERATING_MANUAL.md` §7) — escalate rather than guess.
5. If the live document is unchanged from the reviewed baseline, apply the seven corrections (§8a, §11a, §12, §17, §23a, §29, §32/§33/§34 updates) directly to the live document. Do not replace the entire file wholesale if a targeted edit preserves history/traceability better — use judgment, but the end state must match the corrected candidate's substance.

## 4. Modify Only the Authoritative M020 Design Document

- Only `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` should change as a result of this correction.
- Do **not** touch any M012–M019 document.
- Do **not** touch `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` unless the scope itself is found to require correction (it should not, based on this review).
- Do **not** create any source code, schema, migration, mapper, or repository implementation as part of this correction — this remains a design-only correction pass.

## 5. Rerun Full Hostile Review

After applying the correction:
- Perform a **live, non-portable** hostile review of the corrected design document, following `PROJECT_OPERATING_MANUAL.md` §12.
- Confirm all seven findings (M020-REVIEW-0001 through 0007) are actually resolved in the live document text, not just asserted.
- Look specifically for any new issue introduced by the correction itself (e.g., confirm `LoadedAggregate` is not accidentally specified in a way that reintroduces tracked-aggregate/identity-map behavior; confirm `shared.repository` does not accidentally import any aggregate package).

## 6. Run Validation

```text
security.ps1
verify.ps1
```

Since this is a documentation-only change (no source code exists yet to implement the corrected contracts), expect:
- no test count changes (no new source/tests were added);
- no coverage changes;
- the same architecture-checker and negative-fixture results as before this change;
- `git diff --check` clean;
- final `git status --short` clean after commit.

If `verify.ps1` or `security.ps1` fail for any reason unrelated to this documentation change, that is an Environment Stop or Validation Stop — do not weaken any threshold to force a pass (`PROJECT_OPERATING_MANUAL.md` §16).

## 7. Create a Separate Correction Commit

- Do not amend the original M020 design commit.
- Commit message should reference this correction explicitly, e.g.: `Correct MILESTONE-020 design per independent portable review (7 findings)`.
- Record the starting baseline (from Step 2) and the final HEAD after this commit in your mission report.

## 8. Create the Mandatory External Review Package

Per `PROJECT_OPERATING_MANUAL.md` §21, produce:

```text
external-review/M020-design-correction/
    repository-truth.txt
    complete.diff
    source/            (the corrected MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md)
    tests/             (empty or N/A — no tests exist yet for a design-only document)
    architecture/       (N/A at this stage — no architecture-checker change applied yet)
    evidence/           (verify.ps1 / security.ps1 output)
    review-instructions.md
    sha256-manifest.txt
external-review/M020-design-correction.zip
```

## 9. Freeze Only After Executable Evidence

Do not mark MILESTONE-020 `APPROVED AND FROZEN` from this correction alone. Freeze requires, per `PROJECT_OPERATING_MANUAL.md` §14:
- this correction independently re-reviewed live (not just the portable review reproduced here);
- all required validation passing;
- no unresolved CRITICAL/MAJOR finding;
- clean working tree;
- the external review package from Step 8.

Only after all of the above should MILESTONE-020's design be marked frozen — and note that **freezing the design** is still a separate, earlier gate than implementing, hostile-reviewing, and freezing the actual repository contract *implementation* that follows it (`PROJECT_OPERATING_MANUAL.md` §3, §9–14).

## 10. Update the Checkpoint

Once installed and (if applicable) frozen, update `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` and `PROJECT_OPERATING_MANUAL.md`'s checkpoint blocks to reflect:
- the now-confirmed (or corrected) design commit hash;
- `CURRENT_STATUS` moving from `DESIGN_READY_FOR_INDEPENDENT_REVIEW` to whatever the live review concludes (`DESIGN_APPROVED_AND_FROZEN`, or `NOT_APPROVED` if the live review disagrees with this portable one);
- `M020_FROZEN` updated accordingly.

Do not perform this documentation update from the portable environment — it must follow the live installation, not precede it.
