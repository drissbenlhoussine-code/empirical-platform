# MILESTONE-020 - Domain Repository and Concurrency Contract Design (Portable Correction)

> **PORTABLE DESIGN CANDIDATE — NOT INSTALLED — NOT VERIFIED AGAINST AUTHORITATIVE REPOSITORY.**
> This is a complete corrected design candidate produced by an independent portable review of the original `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md`. It preserves all original valid content and applies only the smallest corrections needed to resolve the findings recorded in `MILESTONE_020_INDEPENDENT_DESIGN_REVIEW_PORTABLE.md`. Sections with no correction are carried forward with materially unchanged content. Corrected or newly added sections are marked **[CORRECTED]** or **[NEW]** in their heading. This document does not freeze MILESTONE-020 and must be reconciled against the live repository before it has any authority (see `M020_PORTABLE_INSTALLATION_INSTRUCTIONS.md`).

## 1. Document Control

| Field | Value |
| --- | --- |
| Document ID | MILESTONE-020 |
| Title | Domain Repository and Concurrency Contract Design |
| Version | 1.1-portable-correction (supersedes 1.0 pending repository installation) |
| Status | PORTABLE DESIGN CANDIDATE — CORRECTED, PENDING REPOSITORY INSTALLATION AND RE-REVIEW |
| Repository | `C:\Users\LuxSy\Documents\trading` |
| Original design baseline | `7d802bc57f085564f682017051f419d69552fb62` |
| Operator-asserted design commit (unverified) | `8dd31a6dc947048beb4fa7d273b0c3e8c31e0183` |
| Scope authority | `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md` |
| Mission type | Portable independent-review correction pass only |
| Repository interfaces implemented | No |
| Repository implementations implemented | No |
| Schemas, migrations, mappers, SQL, APIs, workers, Unit of Work, or runtime composition created | No |
| Live Git verification performed | No |
| Executable test validation performed | No |

## 2. Baseline

Unchanged from the original. Baseline verification required the repository to be on `master` at:

```text
7d802bc57f085564f682017051f419d69552fb62
```

Repository facts at design time (carried forward, unverified in this portable environment):

- M012 canonical runtime domain kernel is approved and frozen.
- M013 process-local domain primitives are implemented.
- M014 EvidencePackage aggregate behavior is frozen.
- M015 Review aggregate behavior is frozen.
- M016 Run aggregate boundary decision is frozen.
- M017 Run aggregate behavior is frozen.
- M018 Campaign aggregate behavior is frozen.
- M019 aggregate reconstruction contract is frozen and implemented.
- PostgreSQL connectivity and low-level infrastructure unit-of-work behavior exist.
- `migrations/versions` is empty.
- No domain repository contracts, domain repository implementations, mappers, schemas, migrations, query models, APIs, workers, outbox, Audit runtime, Decision Candidate, or Decision Freeze behavior exists.

## 3. Problem Statement

Unchanged from the original. The platform now has process-local aggregate behavior and persistence-neutral reconstruction paths, but it still lacks the domain-facing contract that future persistence code must obey. Without a frozen repository and optimistic-concurrency design, the next implementation milestone could accidentally encode hidden choices about load shape, create/update semantics, stale-write handling, expected persisted versions, transaction scope, mapper access, or schema structure.

MILESTONE-020 therefore defines repository contracts and optimistic-concurrency semantics together, without implementing them.

## 4. Frozen Persistence-Readiness Inventory

Unchanged from the original.

| Aggregate | Identity | Current version source | Owned state | Reconstruction state | Repository readiness |
| --- | --- | --- | --- | --- | --- |
| Campaign | `DomainIdentity[CampaignId]` | Domain-managed `AggregateVersion` | `CampaignScopeStatement`, lifecycle, transition history | `CampaignReconstructionState` | Ready for contract design |
| Run | `DomainIdentity[RunId]` plus `CampaignId` context | Domain-managed `AggregateVersion` | ordered `DatasetManifest` tuple, lifecycle, transition history | `RunReconstructionState` | Ready for contract design |
| EvidencePackage | `DomainIdentity[EvidencePackageId]` plus `RunId` context | Domain-managed `AggregateVersion` | ordered `CriterionResult` and `ArtifactReference` tuples, lifecycle, transition history | `EvidencePackageReconstructionState` | Ready for contract design |
| Review | `DomainIdentity[ReviewId]` | Domain-managed `AggregateVersion` | `ReviewTargetReference`, `ReviewerReference`, ordered `ReviewFinding` tuple, disposition metadata, lifecycle, transition history | `ReviewReconstructionState` | Ready for contract design |

Frozen constraints (unchanged):

- public constructors create initial aggregate state only;
- public mutation methods increment `AggregateVersion` after validation succeeds;
- rejected aggregate commands leave state unchanged;
- reconstruction restores exact historical state without incrementing versions or appending history;
- reconstruction modules are internal and not public exports;
- infrastructure persistence services currently expose connectivity and low-level transaction primitives only;
- no schema or mapper exists.

## 5. Design Principles **[CORRECTED — item 6 revised]**

1. Repository contracts are domain-facing, persistence-neutral, and explicit.
2. Repositories return aggregate roots (wrapped at load time — see §12), not reconstruction records.
3. Repository contracts must not mutate aggregate state or increment aggregate versions.
4. Expected persisted version is explicit caller-supplied concurrency data, obtained unambiguously from a `LoadedAggregate` or a prior `SaveResult` — never re-derived by reading `aggregate.version` at an arbitrary later point (see §12).
5. New aggregate creation and existing aggregate save are separate operations.
6. **[CORRECTED]** Load returns a detached `LoadedAggregate[AggregateT]` wrapper containing the aggregate and the persisted version captured at load time, not a bare aggregate.
7. No repository contract exposes SQL, ORM, PostgreSQL, mapper, schema, database session, transaction object, cache object, object storage, or health types.
8. The contract is intentionally minimal: identity load, create, and save only.
9. Cross-aggregate orchestration, Unit of Work implementation, queries, projections, and read models remain deferred.
10. Future implementations must translate infrastructure failures without leaking database-driver details through domain repository contracts.

## 6. Repository Architecture Options

Unchanged from the original — independently reassessed and confirmed in `MILESTONE_020_INDEPENDENT_DESIGN_REVIEW_PORTABLE.md` §C.

| Option | Description | Type safety | Domain terminology | Generic-abstraction risk | Concurrency consistency | Testability | Decision |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A | Generic `Repository[AggregateType, IdentityType]` | Medium | Low | High | High if carefully parameterized | Medium | Rejected |
| B | Aggregate-specific repositories | High | High | Low | Medium unless shared primitives are defined | High | **Selected — independently confirmed** |
| C | Shared generic save/load primitives plus aggregate-specific contracts | High | High | Medium | High | High | Rejected as too framework-like for first contract |
| D | One shared repository service | Low | Low | High | Medium | Low | Rejected |
| E | Repository-free mapper/persistence functions | Low | Low | Medium | Low | Medium | Rejected |

## 7. Selected Repository Architecture

Unchanged.

```text
Aggregate-specific repository contracts
```

Future contract names:

- `CampaignRepository`
- `RunRepository`
- `EvidencePackageRepository`
- `ReviewRepository`

The four contracts must expose the same minimal operation classes:

- load by identity;
- create a new aggregate;
- save an existing aggregate with an expected persisted version.

No generic base repository protocol is selected.

## 8. Contract Placement

Unchanged for the four repository interfaces.

| Option | Future module path | Strength | Risk | Decision |
| --- | --- | --- | --- | --- |
| Aggregate package repository module | `empirical_platform.<aggregate>.repository` | Keeps contract near aggregate language and types | Could tempt aggregates to import repositories | Selected with import-direction rule |
| Persistence contracts package | `empirical_platform.persistence.contracts` | Separates contracts from aggregates | New top-level package not yet present and risks storage-facing naming | Rejected |
| Shared persistence package | `empirical_platform.shared.persistence` | Existing persistence boundary | Would leak aggregate concepts into infrastructure primitives | Rejected |
| Application package | `empirical_platform.application` | Use-case-facing ownership | Application layer does not yet exist | Rejected |
| New aggregate-specific contract packages | e.g. `empirical_platform.campaign_repository` | Strong separation | Adds package sprawl before implementation evidence | Rejected |

Selected future module paths:

- `empirical_platform.campaign.repository`
- `empirical_platform.run.repository`
- `empirical_platform.evidence.repository`
- `empirical_platform.review.repository`

Placement rules (unchanged):

- aggregate modules must not import repository modules;
- repository modules may import their aggregate, identity, version, and shared repository-contract value types;
- repository implementation modules may depend on repository contracts later;
- repository contracts must not import SQLAlchemy, psycopg, PostgreSQL adapters, object storage adapters, schemas, mappers, runtime composition, health, or infrastructure-specific errors;
- repository contracts must not expose internal `_reconstruction` modules.

### 8a. Shared Value/Error Type Placement **[NEW — resolves Finding M020-REVIEW-0001]**

The following types are **not** aggregate-specific and must not be duplicated per aggregate package. They live in one new shared module:

```text
empirical_platform.shared.repository
```

This mirrors the existing precedent of `empirical_platform.shared.domain` (for `AggregateVersion`, `TransitionSequence`, `StateTransitionRecord`) and `empirical_platform.shared.domain.reconstruction` (for `ReconstructionError`/`ReconstructionErrorCategory`). `empirical_platform.shared.repository` contains exactly:

- `LoadedAggregate[AggregateT]` (generic wrapper — see §12);
- `SaveOperation` (enum);
- `SaveResult` (value object);
- `AggregateKind` (enum — see §23a);
- `Retryability` (enum — see §23a);
- `RepositoryContractError` and its five subclasses (`AggregateNotFound`, `AggregateAlreadyExists`, `OptimisticConcurrencyConflict`, `InvalidAggregateForPersistence`, `InvalidPersistedAggregateState`).

`empirical_platform.shared.repository` must not import SQLAlchemy, psycopg, boto3/botocore, any aggregate package, or any `_reconstruction` module. It may import `empirical_platform.shared.domain` (for `AggregateVersion`) and `empirical_platform.identifiers` (for `DomainIdentity`). Each aggregate's own `<aggregate>.repository` module imports from `shared.repository` and from its own aggregate package only.

Future architecture-checker changes required before implementation: `shared.repository` must be importable by all four aggregate `.repository` modules; no aggregate `.repository` module may be imported by another aggregate's package; `shared.repository` may not import any aggregate package (to prevent cycles).

## 9. Sync/Async Decision

Unchanged — independently confirmed in review §E.

| Option | Strength | Risk | Decision |
| --- | --- | --- | --- |
| Synchronous repository contracts | Matches current SQLAlchemy Engine/Core foundation, current tests, and process-local aggregate style | Future async API may require adapter boundary | Selected |
| Asynchronous repository contracts | Aligns with possible future async API/workers | Current persistence foundation is synchronous; would require async driver and dual mental model | Rejected |
| Dual sync and async contracts | Flexible | Duplicates contract surface and test matrix | Rejected |

```text
Synchronous contracts only
```

## 10. Aggregate Coverage

Unchanged.

| Repository | Identity input | Aggregate output/input |
| --- | --- | --- |
| CampaignRepository | `DomainIdentity[CampaignId]` | `Campaign` |
| RunRepository | `DomainIdentity[RunId]` | `Run` |
| EvidencePackageRepository | `DomainIdentity[EvidencePackageId]` | `EvidencePackage` |
| ReviewRepository | `DomainIdentity[ReviewId]` | `Review` |

## 11. Identity Inputs **[CORRECTED — assumption note added]**

Selected identity rule (unchanged, frozen identity semantics not modified per mission instruction):

```text
Repository load/create/save operations use canonical DomainIdentity[AggregateId].
```

Rationale (unchanged):

- aggregate roots already expose `DomainIdentity[...]`;
- M012 requires governance ID plus runtime UUID separation;
- using raw governance IDs would lose runtime identity and identity-kind validation;
- using runtime UUID alone would lose governance traceability;
- using `DomainIdentity[...]` keeps repository keys aligned with aggregate identity.

### 11a. Documented Caller-Feasibility Assumption **[NEW — resolves Finding M020-REVIEW-0002]**

This design assumes callers retain the **full** `DomainIdentity[AggregateId]` (governance ID paired with runtime UUID) from the moment it was first produced — i.e., from the aggregate's creation (`add()` call and its `SaveResult`, or the in-memory construction that preceded it), or from a prior `get()`'s returned `LoadedAggregate`. This design does **not** define, and explicitly defers, any mechanism for resolving a full `DomainIdentity` from a governance ID alone (e.g., an external index, a governance-ID-keyed lookup service, or a secondary repository method). If a future caller genuinely only possesses a bare governance ID with no retained runtime UUID, that caller cannot use these repository contracts as specified, and a separate, explicitly scoped milestone would be required to add such a resolution path. This is a **documentation-only clarification**; no new mechanism is introduced by this correction.

## 12. Load Semantics **[CORRECTED — LoadedAggregate wrapper adopted, resolves Finding M020-REVIEW-0003 — CRITICAL]**

Selected load operation semantics:

- method name: `get`;
- input: `DomainIdentity[AggregateId]`;
- **successful result: `LoadedAggregate[AggregateT]`, an immutable wrapper with exactly two fields: `aggregate` (the detached aggregate root) and `persisted_version` (the `AggregateVersion` captured atomically by the repository at the moment of load);**
- missing identity: raises `AggregateNotFound`;
- malformed persisted state or reconstruction failure: raises `InvalidPersistedAggregateState`;
- repository interfaces do not expose reconstruction state records;
- repository interfaces do not expose internal `_reconstruct_*` factories;
- `LoadedAggregate.persisted_version` is set once at load time and never recomputed by the wrapper itself;
- row locking is excluded from the contract;
- caching is excluded from the contract;
- no transaction context is accepted by the public repository contract.

The name `get` is selected because the operation is direct identity retrieval, not a broad query or search. The absence of a matching aggregate is exceptional for this contract because callers must already hold a canonical identity.

**Why `LoadedAggregate` instead of a bare aggregate return (correction rationale):** the original design's bare-aggregate return relied entirely on caller discipline to capture `aggregate.version` *before* any mutation and thread that captured value separately through to `save()`. Because `AggregateVersion` continues to live on the same aggregate object the caller mutates, the natural, easy-to-write call site `save(agg, agg.version)` silently reads the **post-mutation** version instead of the load-time version, which can never trigger `OptimisticConcurrencyConflict` even when a real conflict exists — because the "expected" value is always whatever the object currently holds. Returning `LoadedAggregate` with a **separately named, separately typed field** for the persisted version removes this hazard: `loaded.persisted_version` is physically a different attribute from `loaded.aggregate.version`, so a caller who wants to (mis)use the post-mutation value has to actively write `loaded.aggregate.version` instead of `loaded.persisted_version` — a deliberate, visible choice rather than an accidental one.

Correct call pattern:

```text
loaded = campaign_repo.get(identity)
loaded.aggregate.activate(reason="...")
result = campaign_repo.save(loaded.aggregate, loaded.persisted_version)
# result.persisted_version becomes the new expected_persisted_version for any subsequent save
```

Load followed by save is still **not** assumed to occur in one database transaction. The caller must supply `expected_persisted_version` obtained from `LoadedAggregate.persisted_version` or from a prior `SaveResult.persisted_version`.

## 13. Not-Found Semantics

Unchanged.

| Option | Strength | Risk | Decision |
| --- | --- | --- | --- |
| Optional return | Simple | Missing identity can be ignored accidentally | Rejected |
| Contract-level exception | Clear failure, easy API translation, consistent with identity-required load | Selected |
| Result type | Explicit but verbose | Adds wrapper type before broader result model exists | Rejected |

```text
Missing aggregate identity raises AggregateNotFound.
```

`AggregateNotFound` is persistence-neutral and contains the requested identity context. Implementations must not leak database no-row, SQLAlchemy, or driver details.

## 14. Create/Save Operation Model

Unchanged.

| Option | Strength | Risk | Decision |
| --- | --- | --- | --- |
| Separate `add` and `save` | Caller intent is explicit; duplicate-create and stale-update are distinct | Two operations instead of one | Selected |
| Single save with creation marker | One method surface | Creation and update intent become less legible | Rejected |
| Upsert | Convenient | Destroys concurrency intent and can hide duplicates | Rejected |

- `add` persists a new aggregate that must not already exist.
- `save` persists an existing aggregate only when the expected persisted version matches the durable version.

## 15. Version Vocabulary

Unchanged — independently confirmed correct in review §J.

| Term | Meaning |
| --- | --- |
| Aggregate current version | The `AggregateVersion` currently held by the in-memory aggregate after domain mutations. |
| Expected persisted version | The `AggregateVersion` the caller believes is currently durable, obtained from `LoadedAggregate.persisted_version` or a prior `SaveResult.persisted_version`, and against which `save` must compare atomically. |
| Persisted version after save | The aggregate current version successfully stored by the repository, returned as `SaveResult.persisted_version`. |
| New aggregate state | The condition where no persisted version exists yet for the aggregate identity. |

```text
save(existing aggregate, expected_persisted_version: AggregateVersion)
```

`AggregateVersion | None` is rejected for existing save. Creation does not pass `None`; creation uses `add`.

## 16. New Aggregate Creation

Unchanged — independently confirmed implementation-ready in review §H.

- creation intent is expressed by `add`;
- `add` accepts an aggregate with canonical `DomainIdentity[...]`;
- the aggregate must not already be persisted;
- duplicate identity raises `AggregateAlreadyExists`;
- concurrent insert races must result in exactly one success and one `AggregateAlreadyExists`;
- database uniqueness errors are translated and hidden;
- no preflight `exists()` check may be treated as the concurrency guarantee;
- a newly created aggregate may have any valid non-negative current `AggregateVersion`;
- version zero is not required for first persistence;
- `add` returns a `SaveResult` with operation `CREATED` and persisted version equal to the aggregate current version.

## 17. Existing Aggregate Save **[CORRECTED — two undefined cases resolved, Findings M020-REVIEW-0004 and 0005]**

- `save` accepts an aggregate and explicit `expected_persisted_version`;
- the repository atomically compares the durable version to `expected_persisted_version`;
- on match, it persists the aggregate's current version and complete aggregate state;
- on mismatch (durable version exists but differs from `expected_persisted_version`), it raises `OptimisticConcurrencyConflict`;
- **[NEW] if no durable row exists for the aggregate's identity at all, `save` raises `AggregateNotFound`** — the same error `get()` raises for the same underlying fact ("no durable row for this identity"). `save` must never insert a missing identity as a side effect of this case.
- **[NEW] if the aggregate's current version is strictly less than `expected_persisted_version`, `save` raises `InvalidAggregateForPersistence`.** This is distinct from `OptimisticConcurrencyConflict`: a current version below the expected persisted version cannot result from a legitimate concurrent write elsewhere (those produce current ≥ expected, durable > expected — see §20); it indicates the in-memory aggregate itself is inconsistent with the caller's own belief about durable state, most plausibly a caller/programming error (e.g., an `expected_persisted_version` sourced from a different aggregate instance or a stale `LoadedAggregate`). `InvalidAggregateForPersistence`'s existing stated purpose ("not retryable without code/data correction") matches this case exactly; no new error type is introduced.
- repository save never increments aggregate version;
- repository save never mutates aggregate state;
- repository save does not repair malformed aggregate state;
- repository save does not emit domain events, outbox records, Audit records, logs as business evidence, or external calls;
- persisted aggregate state must preserve reconstruction fidelity.

The current aggregate version must be greater than or equal to the expected persisted version for a normal (match or mismatch-conflict) outcome. Greater-than covers accepted local mutations. Equal-to covers unchanged saves (§18). Less-than is the new, now-explicit `InvalidAggregateForPersistence` case above.

## 18. Unchanged Save

Unchanged — independently confirmed correct in review §K.

| Option | Strength | Risk | Decision |
| --- | --- | --- | --- |
| Idempotent no-op success | Simple repeated-save behavior; no unnecessary write required | Caller may not notice no change unless result says so | Rejected in favor of explicit result |
| Explicit no-change result | Deterministic and visible | Requires result object | Selected |
| Contract rejection | Forces callers to know mutation state | Makes repeated-save workflows brittle | Rejected |
| Storage write allowed but not required | Portable implementation | Ambiguous to callers without result | Rejected |

```text
aggregate current version == expected persisted version
```

is a valid unchanged save that returns `SaveResult(operation=UNCHANGED, persisted_version=current_version)`. Implementations may avoid physical writes for unchanged saves, but they must still validate that the expected persisted version matches durable state.

## 19. Repeated Save

Unchanged, restated with the corrected `LoadedAggregate` vocabulary:

1. `loaded = repo.get(identity)` → `loaded.persisted_version == 5`.
2. Aggregate mutates locally to current version 7 (via `loaded.aggregate`).
3. Caller saves with `expected_persisted_version = loaded.persisted_version` (5).
4. Repository persists version 7 and returns `SaveResult(operation=UPDATED, persisted_version=7)`.
5. A second save without further mutation must use `expected_persisted_version = 7` (the prior `SaveResult.persisted_version`, **not** a re-read of `loaded.aggregate.version`, which may have advanced further if additional mutations occurred).
6. Reusing `expected_persisted_version = 5` must raise `OptimisticConcurrencyConflict` if durable version is 7.
7. Saving again with `expected_persisted_version = 7` (and no further mutation) returns `UNCHANGED`.

Repositories do not track state internally. The caller owns propagation of the latest persisted version, now made structurally explicit via `LoadedAggregate.persisted_version` and `SaveResult.persisted_version`.

## 20. Stale-Write Semantics

Unchanged.

- error type: `OptimisticConcurrencyConflict`;
- includes aggregate identity;
- includes expected persisted version;
- includes aggregate current version;
- includes actual persisted version when safely available;
- actual persisted version is optional because not all storage backends may return it without a second read;
- retryability is `Retryability.RETRYABLE_AFTER_RELOAD` **[CORRECTED — now typed, see §23a]**;
- no automatic retry;
- no blind overwrite;
- no aggregate mutation;
- no database exception leakage.

## 21. Concurrent Creation

Unchanged.

- `add` is atomic for one aggregate identity;
- if the identity already exists, raise `AggregateAlreadyExists`;
- if two creators race, exactly one succeeds and the other receives `AggregateAlreadyExists`;
- database uniqueness errors are translated;
- no overwrite occurs;
- no repository preflight `exists()` method is selected as a correctness mechanism;
- retry ownership stays with caller/application policy, not repository contract.

## 22. Save Result

Unchanged shape — module placement resolved in §8a.

| Field | Meaning |
| --- | --- |
| `operation` | One of `SaveOperation.CREATED`, `SaveOperation.UPDATED`, `SaveOperation.UNCHANGED` |
| `persisted_version` | Aggregate current version successfully made durable |

No database metadata, row count, transaction ID, ETag, timestamp, session object, lock token, mapper record, or schema information is returned. `add` and `save` share the same `SaveResult` type.

## 23. Error Taxonomy **[CORRECTED — two new cases added below, field types resolved in §23a]**

Selected base:

```text
RepositoryContractError
```

Selected contract errors:

| Error | Base | Required context | Retryability | Message rule |
| --- | --- | --- | --- | --- |
| `AggregateNotFound` | `RepositoryContractError` | aggregate kind, identity | `Retryability.NOT_RETRYABLE` without new identity | Safe message, no storage details |
| `AggregateAlreadyExists` | `RepositoryContractError` | aggregate kind, identity | `Retryability.NOT_RETRYABLE` without new identity or caller policy | Safe message, no uniqueness/index details |
| `OptimisticConcurrencyConflict` | `RepositoryContractError` | aggregate kind, identity, expected persisted version, aggregate current version, optional actual persisted version | `Retryability.RETRYABLE_AFTER_RELOAD` | Safe message, no SQL/driver details |
| `InvalidAggregateForPersistence` | `RepositoryContractError` | aggregate kind, identity if available, reason | `Retryability.NOT_RETRYABLE` without code/data correction | Safe message |
| `InvalidPersistedAggregateState` | `RepositoryContractError` | aggregate kind, identity if available, reconstruction category/field when safe | `Retryability.NOT_RETRYABLE` without data correction | Safe message |

**[NEW]** Exact usages introduced by §17's correction:
- `save()` on a missing durable identity → `AggregateNotFound` (aggregate kind + identity).
- `save()` with aggregate current version < expected persisted version → `InvalidAggregateForPersistence` (aggregate kind, identity, reason = "current version below expected persisted version").

`ReconstructionError` handling (unchanged):

- ordinary callers do not receive raw reconstruction state;
- future repository implementations translate `ReconstructionError` to `InvalidPersistedAggregateState`;
- exception chaining may preserve original exception for logs/debugging, but the public contract error remains persistence-neutral.

Infrastructure availability failures remain outside the domain repository error taxonomy unless a later application-service boundary needs a separate infrastructure-facing classification.

### 23a. Field Type Resolution **[NEW — resolves Findings M020-REVIEW-0006 and 0007]**

Two supporting enums, placed in `empirical_platform.shared.repository` alongside the error types:

```text
AggregateKind: CAMPAIGN | RUN | EVIDENCE_PACKAGE | REVIEW
Retryability: RETRYABLE_AFTER_RELOAD | NOT_RETRYABLE
```

Every `RepositoryContractError` subclass's "aggregate kind" field is typed `AggregateKind`. Every error's implicit or explicit retryability is typed `Retryability`. No error carries a bare string for either concept.

## 24. Reconstruction Integration

Unchanged — independently verified consistent with frozen M019 in review §N.

Frozen load flow:

```text
repository implementation
-> mapper
-> aggregate-specific ReconstructionState
-> internal _reconstruct_* factory
-> aggregate root (wrapped in LoadedAggregate at the repository boundary)
```

Frozen save flow:

```text
aggregate root
-> mapper
-> persistence representation
-> atomic persistence
```

Contract rules (unchanged):

- repository interfaces expose aggregates (via `LoadedAggregate`) only;
- reconstruction state records remain internal to mapper/reconstruction integration;
- `_reconstruct_*` factories remain internal;
- mapper design is deferred;
- repository implementation is deferred;
- public exports do not change beyond the additions in §8a;
- architecture-checker changes are deferred until implementation scope, except the `shared.repository` import-direction rule noted in §8a, which must be added at implementation-scope time.

## 25. Atomic Save Boundary

Unchanged — independently confirmed correct in review §O.

A successful `add` or `save` is atomic across one aggregate root: identity and context identifiers; lifecycle state; current aggregate version; next transition sequence; transition history; root scalar state; owned immutable value objects; ordered owned collections; terminal metadata. No partial save may be observable through future repository contracts.

## 26. Transaction Boundary

Unchanged.

- one aggregate `add` or `save` is atomic;
- repository contracts do not accept database sessions;
- repository contracts do not expose transaction objects;
- repository contracts do not expose Unit of Work objects;
- load followed by save is not assumed to run in one transaction;
- row locking is deferred;
- automatic retry is deferred;
- multi-aggregate transactions are deferred;
- application orchestration remains deferred.

The existing low-level `PersistenceUnitOfWork` remains an infrastructure primitive, not a domain repository contract surface.

## 27. Tracking Model

Unchanged in substance; restated with `LoadedAggregate` vocabulary.

| Option | Strength | Risk | Decision |
| --- | --- | --- | --- |
| Detached aggregates (via `LoadedAggregate`) | Transparent expected-version passing; no hidden Unit of Work | Caller must carry `persisted_version` explicitly | Selected |
| Tracked aggregates | Convenient save after load | Hidden identity map, transaction coupling, lifecycle complexity | Rejected |

```text
Detached
```

Repositories do not track loaded aggregate instances. They do not remember expected persisted versions on the caller's behalf beyond what is returned once in `LoadedAggregate`/`SaveResult`. They do not maintain identity maps. They do not mutate aggregate objects after save.

## 28. Query/Delete Exclusions

Unchanged — independently confirmed correct.

Explicitly excluded: delete; list/search/filter/pagination; lifecycle queries; `exists()` as a contract operation; Campaign-to-Run lookup; Run-to-EvidencePackage lookup; EvidencePackage-to-Review lookup; read models; projections; analytics; reporting; repository methods that cross aggregate boundaries.

## 29. Contract Testing **[CORRECTED — two save-failure cases added]**

Required load tests (unchanged): successful load for each aggregate returning `LoadedAggregate`; missing identity raises `AggregateNotFound`; malformed persisted state raises `InvalidPersistedAggregateState`; reconstruction failures are translated; loaded aggregate state matches durable state exactly; `LoadedAggregate.persisted_version` matches the durable version at load time.

Required create tests (unchanged): successful create; create with positive aggregate current version; duplicate identity; simulated concurrent create; no aggregate mutation by repository.

Required save tests:

- successful mutated aggregate save;
- unchanged save;
- stale expected persisted version → `OptimisticConcurrencyConflict`;
- **[NEW] missing durable identity → `AggregateNotFound`;**
- **[NEW] aggregate current version below expected persisted version → `InvalidAggregateForPersistence`;**
- repeated save with new token (from prior `SaveResult`) succeeds;
- repeated save with old/stale token fails;
- save result operation and persisted version are exactly as specified;
- atomic root, owned-collection, metadata, and history boundary.

Required error tests (unchanged): exact contract error types; identity/version context; no database exception leakage; no SQL/ORM type exposure; `AggregateKind`/`Retryability` fields are the typed enums, not bare strings.

Atomicity (unchanged): no partially persisted root/history/owned collections.

The same contract suite must apply to Campaign, Run, EvidencePackage, and Review repositories.

## 30. Compatibility Guarantees

Unchanged.

Future repository contracts must not: modify frozen aggregates; modify reconstruction contracts; increment aggregate versions; store expected persisted version inside aggregate objects; expose reconstruction state records; expose internal reconstruction factories; expose SQL, ORM, PostgreSQL, object storage, or schema types; introduce delete/query semantics; require schemas yet; define mapping yet; require Unit of Work; define multi-aggregate transactions; add APIs or workers; introduce Audit, Decision Candidate, Decision Freeze, trading, vendor, or empirical execution behavior.

## 31. Deferred Work

Unchanged. Deferred after M020: source implementation of repository contracts; shared repository result/error value implementation; repository implementations; mappers; serialization format; PostgreSQL schema and migrations; SQL; ORM mapping; Unit of Work integration; row locking; retry policy; application services; runtime composition; API and worker integration; read models and projections; Audit runtime; Decision Candidate; Decision Freeze.

## 32. Risks and Mitigations **[CORRECTED — two new risks added]**

| Risk | Severity | Mitigation |
| --- | --- | --- |
| Aggregate-specific contracts duplicate common shapes | MINOR | Permit shared test helpers later, but keep public contracts aggregate-specific. |
| Detached model burdens callers with expected-version propagation | MAJOR | `SaveResult` always returns persisted version; `LoadedAggregate` always returns it at load time; future application services must carry it explicitly. |
| No raw `exists()` method complicates creation prechecks | MINOR | Correctness belongs to atomic `add`; optional user-facing prechecks can be read-model work later. |
| Synchronous contracts may need async wrapping later | MINOR | Keep async conversion at application/runtime boundary if APIs or workers require it. |
| Contract placement inside aggregate package could pollute domain modules | MAJOR | Add architecture-checker rule before implementation: aggregates cannot import repositories; repositories cannot import infrastructure; `shared.repository` cannot import any aggregate package. |
| Error taxonomy may overfit before implementation | MINOR | Keep errors minimal and persistence-neutral; defer infrastructure failure taxonomy. |
| **[NEW]** Callers could still bypass `LoadedAggregate` discipline by manually constructing an `expected_persisted_version` from an unrelated source | MAJOR | Document the correct call pattern prominently (§12); rely on contract tests (§29) to catch misuse in aggregate/application-service tests once implemented. |
| **[NEW]** Governance-ID-only callers cannot use these contracts without a retained `DomainIdentity` | MAJOR | Documented as an explicit out-of-scope assumption (§11a); flag for a future, separately scoped identity-resolution milestone if it proves necessary. |

## 33. Hostile Self-Review **[CORRECTED — second-pass entries added]**

Original first-pass entries (unchanged):

| ID | Severity | Section | Finding | Impact | Correction | Disposition |
| --- | --- | --- | --- | --- | --- | --- |
| M020-DESIGN-ISSUE-0001 | MAJOR | 15 | Initial draft risked conflating expected persisted version with aggregate current version. | Could allow blind overwrite or ambiguous repeated saves. | Added four-term version vocabulary and explicit expected-version save rule. | Resolved |
| M020-DESIGN-ISSUE-0002 | MAJOR | 14, 16 | Creation semantics initially risked requiring version zero for first persistence. | Would contradict process-local mutation before persistence. | Selected `add` and allowed any valid current aggregate version. | Resolved |
| M020-DESIGN-ISSUE-0003 | MAJOR | 18, 19 | Unchanged and repeated save behavior needed deterministic token propagation. | Future implementations could diverge. | Selected `UNCHANGED` SaveResult and required caller to use latest persisted version after save. | Resolved |
| M020-DESIGN-ISSUE-0004 | MAJOR | 26, 27 | Tracked repositories could smuggle Unit of Work behavior into contracts. | Hidden state and transaction coupling. | Selected detached aggregates and explicit expected-version passing. | Resolved |
| M020-DESIGN-ISSUE-0005 | MAJOR | 8, 24 | Repository placement near aggregate packages could expose reconstruction internals. | Public callers might import `_reconstruction`. | Selected aggregate-local repository modules but kept reconstruction internal and required future architecture checks. | Resolved |
| M020-DESIGN-ISSUE-0006 | MINOR | 23 | Infrastructure availability errors were tempting to add to domain taxonomy. | Could leak foundation error concerns into domain contracts. | Kept domain repository errors focused and deferred infrastructure failure classification. | Resolved |
| M020-DESIGN-ISSUE-0007 | MINOR | 28 | `exists()` could sneak in as creation convenience. | Could become false concurrency guarantee. | Excluded `exists()` from contract and made atomic `add` authoritative. | Resolved |

**[NEW]** Second-pass entries, from the portable independent review (`MILESTONE_020_INDEPENDENT_DESIGN_REVIEW_PORTABLE.md`):

| ID | Severity | Section | Finding | Impact | Correction | Disposition |
| --- | --- | --- | --- | --- | --- | --- |
| M020-REVIEW-0001 | MAJOR | 8, 22, 23 | No module placement for shared value/error types. | Implementer would have to invent placement. | Added §8a: `empirical_platform.shared.repository`. | Resolved |
| M020-REVIEW-0002 | MAJOR | 11 | No discussion of caller feasibility for `DomainIdentity` possession before load. | Silent operational assumption. | Added §11a documented assumption. | Resolved (documentation only) |
| M020-REVIEW-0003 | CRITICAL | 12, 17-19 | Bare-aggregate load return allows silent capture of post-mutation version as the save token. | Optimistic concurrency could be silently defeated by natural-looking caller code. | Adopted `LoadedAggregate[AggregateT]` wrapper (§12). | Resolved |
| M020-REVIEW-0004 | MAJOR | 17 | No defined behavior for `save()` on a missing durable identity. | Implementer must invent; risk of accidental upsert. | `save()` on missing identity raises `AggregateNotFound` (§17). | Resolved |
| M020-REVIEW-0005 | MAJOR | 17 | No defined behavior for current version < expected persisted version. | Implementer must invent; risk of conflating caller error with concurrency conflict. | Raises `InvalidAggregateForPersistence` (§17). | Resolved |
| M020-REVIEW-0006 | MINOR | 23 | "aggregate kind" field type unspecified. | Type ambiguity. | Added `AggregateKind` enum (§23a). | Resolved |
| M020-REVIEW-0007 | MINOR | 20, 23 | "retryability" field type unspecified. | Type ambiguity. | Added `Retryability` enum (§23a). | Resolved |

No unresolved CRITICAL or MAJOR finding remains after this correction pass.

## 34. Acceptance Gate

| Gate | Result |
| --- | --- |
| Repository architecture selected | PASS |
| Contract placement selected — repository interfaces | PASS |
| Contract placement selected — shared value/error types | PASS **[was gap, now corrected]** |
| Sync/async model selected | PASS |
| All four aggregates covered | PASS |
| Identity input selected | PASS |
| Identity caller-feasibility assumption documented | PASS **[new]** |
| Load and not-found semantics selected | PASS |
| Load concurrency-token capture made structurally safe | PASS **[was gap, now corrected]** |
| Create/save model selected | PASS |
| Expected persisted version semantics complete | PASS |
| New aggregate creation semantics complete | PASS |
| Existing save semantics complete, including missing-identity and below-expected-version cases | PASS **[was gap, now corrected]** |
| Unchanged and repeated save semantics complete | PASS |
| Stale-write and concurrent creation semantics complete | PASS |
| Save result selected | PASS |
| Error taxonomy selected, with typed fields | PASS **[was gap, now corrected]** |
| Reconstruction integration preserved | PASS |
| Atomicity and transaction boundaries limited | PASS |
| Tracking model selected | PASS |
| Query/delete exclusions explicit | PASS |
| Mapper/schema/migration/implementation deferred | PASS |
| No source code introduced | PASS |
| Live Git verification performed | **N/A — portable environment; must be re-verified on installation** |

## 35. Final Decision

MILESTONE-020 (corrected) selects aggregate-specific, synchronous, aggregate-local future repository contracts with explicit optimistic-concurrency semantics, a `LoadedAggregate`-wrapped load result, an explicit `shared.repository` module for cross-aggregate value/error types, and fully-defined save-failure behavior for all eight cases enumerated by the reviewing mission.

This corrected candidate is a **portable design candidate only**. It does not freeze MILESTONE-020. Freezing requires: installation against the live repository, a live (non-portable) independent hostile review confirming this correction, full executable validation (`security.ps1`, `verify.ps1`), and a separate correction commit, per `PROJECT_OPERATING_MANUAL.md` §12–14.

Final status:

```text
PORTABLE DESIGN CANDIDATE — CORRECTED — PENDING REPOSITORY INSTALLATION AND LIVE INDEPENDENT REVIEW
```
