# MILESTONE-020 — Independent Repository and Concurrency Contract Design Review (Portable)

## A. Review Classification

```text
PORTABLE DESIGN CANDIDATE
NOT INSTALLED
NOT VERIFIED AGAINST AUTHORITATIVE REPOSITORY
```

This review was produced in a chat/phone environment with no live Git access, no test execution, and no repository mutation capability. It is an **independent review of a design document**, not a repository operation. No claim in this document should be read as: live Git verification, executable test validation, real commit creation, repository mutation, implementation acceptance, or milestone freeze. The reviewer treated `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` as an **untrusted proposal** throughout, per `PROJECT_OPERATING_MANUAL.md` §12.

## B. Source Basis

Read in full before this review was written:

1. `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md`
2. `PROJECT_OPERATING_MANUAL.md`
3. `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_SCOPE_SELECTION.md`
4. `MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN.md` (full text, all 35 sections)
5. `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_DESIGN.md`
6. `MILESTONE_019_AGGREGATE_RECONSTRUCTION_CONTRACT_IMPLEMENTATION.md`
7. `MILESTONE_012_CANONICAL_RUNTIME_DOMAIN_KERNEL_DESIGN.md`
8. `MILESTONE_016_RUN_AGGREGATE_BOUNDARY_RECONCILIATION_DECISION.md`

All eight were retrieved from the currently attached Claude Project file
(`EMPIRICAL_TRADING_PLATFORM_CLAUDE_PROJECT_CORE.md`, the single-file bundle), not from a live repository.

## C. Architecture Reassessment

The design's own comparison (Design §6) evaluated five options:

| Option | Reviewer's independent assessment |
| --- | --- |
| A. Generic `Repository[AggregateType, IdentityType]` | Correctly rejected. A generic repository would erase the aggregate-specific vocabulary (`CampaignRepository.get`, not `Repository[Campaign, CampaignId].get`) that M012–M019 deliberately built up, and M020's own scope-selection document already flagged "no generic abstraction by habit" as a hostile-review criterion. Agree with rejection. |
| B. Aggregate-specific repositories | **Selected by the design; independently confirmed correct.** Matches the pattern already used for aggregate-specific reconstruction contracts in M019 (`_reconstruct_*` per aggregate, not one generic reconstructor). Consistent, low generic-abstraction risk, high type safety. |
| C. Shared generic save/load primitives plus aggregate-specific contracts | Rejected by the design as "too framework-like... before evidence proves the four contracts need one." This is a reasonable precautionary rejection, but the design asserts the risk rather than demonstrating it with a concrete example of what such a shared primitive would look like or where it would go wrong. **OBSERVATION**, not blocking (see Finding OBS-01). |
| D. One shared repository service | Correctly rejected — collapses aggregate boundaries that M014–M018 spent four milestones establishing. |
| E. Repository-free persistence functions | Correctly rejected — would bypass a domain-facing port, forcing callers to depend on mapper/persistence internals directly, contradicting the "reconstruction stays internal" rule frozen in M019. |

**Independent conclusion: Option B (aggregate-specific repositories) is confirmed as the correct architecture.** The reviewer does **not** override this selection. No CRITICAL or MAJOR finding applies to Section 6/7 of the design.

## D. Contract Placement

The design (Design §8) gives exact future module paths for the four repository *interfaces*:
- `empirical_platform.campaign.repository`
- `empirical_platform.run.repository`
- `empirical_platform.evidence.repository`
- `empirical_platform.review.repository`

**This is correct and sufficient for the four repository protocols themselves.**

However, the design **never states an exact module path** for the shared, aggregate-neutral conceptual types it also defines: `SaveOperation`, `SaveResult`, `RepositoryContractError` and its five subclasses (`AggregateNotFound`, `AggregateAlreadyExists`, `OptimisticConcurrencyConflict`, `InvalidAggregateForPersistence`, `InvalidPersistedAggregateState`). Design §22 and §23 define their *conceptual shape* but not their *package location*. This is a genuine gap — see Finding M020-REVIEW-0001 (MAJOR).

The reviewer's independent placement decision (detailed in the corrected design) is:

```text
empirical_platform.shared.repository
```

This mirrors the existing, already-frozen precedent of `empirical_platform.shared.domain` (housing `AggregateVersion`, `TransitionSequence`, `StateTransitionRecord` — genuinely cross-aggregate, persistence-neutral types) and `empirical_platform.shared.domain.reconstruction` (housing `ReconstructionError`/`ReconstructionErrorCategory` — the M019 precedent for exactly this kind of "shared error taxonomy" placement). A new sibling module, `empirical_platform.shared.repository`, is the natural, consistent placement: cross-aggregate, free of any single aggregate's import, and free of infrastructure imports (SQLAlchemy/psycopg/boto3 remain forbidden here exactly as they are in `shared.domain`).

## E. Sync/Async

**Confirmed independently.** Design §9 selects synchronous-only contracts. This is correct: the platform's only persistence connectivity today (`shared/persistence/postgres.py`, per Master Context §9) is a synchronous SQLAlchemy Engine/Core foundation, and no async driver, async API, or async worker exists anywhere in the frozen inventory. Introducing async now would be exactly the kind of "premature abstraction ahead of evidence" that `PROJECT_OPERATING_MANUAL.md` §18 forbids. No finding.

## F. Identity Input

Design §11 selects `DomainIdentity[AggregateId]` as the sole repository lookup key, correctly preserving the frozen M012 governance-ID/runtime-UUID pairing (Master Context §6; M012 §7 "Identifier Inventory and Reconciliation").

**The reviewer does not change this frozen identity semantics** (per this mission's explicit instruction). However, the design does not address a real feasibility question the mission specifically asked to be assessed: **can a realistic caller possess the full paired `DomainIdentity[AggregateId]` — governance ID *and* runtime UUID — before ever calling `get()`?**

M012 §7 states identifier reservation and aggregate creation are atomic, and that "runtime UUIDs are never displayed as replacement governance references." This implies the natural place a caller first receives the *full* paired `DomainIdentity` is at the moment of aggregate creation (the `add()` call itself, or whatever upstream flow constructs the aggregate). If a caller only ever holds a human-facing governance ID (e.g., `RUN-0042`, printed on a report or typed into a URL) and never retained the paired runtime UUID from creation time, `get()` as specified has no path for that caller to resolve the pair — this is a plausible, realistic operational gap: an application layer that persists only governance IDs (e.g., in a URL, in a user's saved bookmark, in an external ticket system) would have no way to reconstruct the runtime UUID half of `DomainIdentity` without a resolution mechanism that this design does not define and that is out of scope for M020 to invent.

This is not a defect in M020 to *fix* on its own — creating a governance-ID resolution index would be new scope, and this mission is explicitly forbidden from inventing new persistence mechanisms. It is a **documented assumption gap**: see Finding M020-REVIEW-0002 (MAJOR) — the design should say explicitly that callers are assumed to retain the full `DomainIdentity` from creation time or from a prior `get()`/`add()`/`save()` result, and that governance-ID-only resolution is out of scope and deferred, rather than leaving this silent.

## G. Load and Version Token

This is the review's most significant technical finding.

Design §12 states: *"loaded aggregate does not carry a persistence token inside itself"* and *"the caller must supply the expected persisted version obtained from load or a prior successful save."* This implicitly selects the mission's **Option A** (`get(identity) -> aggregate only; caller captures aggregate.version immediately`) — but the design never names this as a selected option, never states it was compared against Option B (`LoadedAggregate[Aggregate]` wrapper), and never warns about the option's most dangerous failure mode.

**The hazard:** `AggregateVersion` is a live, mutable-in-place-conceptually property of the aggregate — every accepted domain mutation increments `aggregate.version`. If a caller writes the natural-looking sequence:

```text
agg = campaign_repo.get(identity)
agg.activate(reason=...)                      # agg.version now incremented in memory
campaign_repo.save(agg, agg.version)           # BUG: reads the *post-mutation* version
```

...the "expected persisted version" passed to `save()` is silently the *new*, post-mutation version rather than the version that was actually durable at load time. Because `save()`'s optimistic-concurrency check compares `expected_persisted_version` against the *durable* version (not the in-memory one), and the caller has (by construction, in this buggy-but-natural pattern) always supplied a value equal to whatever the aggregate currently holds, this pattern can never detect a real conflict — it silently defeats optimistic concurrency for exactly the callers most likely to write it this way, because the API gives no separate name or separate capture point for "the version I loaded with" versus "the version I currently hold after mutating."

This is exactly the "implicit concurrency-token acquisition" hazard this mission's own instructions named as a blocking-finding category, and it is real, not hypothetical — it is the single easiest incorrect usage pattern of the API as specified.

**Independent decision:** adopt **Option B** — `get()` returns `LoadedAggregate[AggregateT]`, a small immutable wrapper with two distinctly-named fields: `.aggregate` (the domain object) and `.persisted_version` (captured once, atomically, at load time, never touched again). The correct call pattern becomes unambiguous:

```text
loaded = campaign_repo.get(identity)
loaded.aggregate.activate(reason=...)
campaign_repo.save(loaded.aggregate, loaded.persisted_version)
```

`loaded.persisted_version` is a separate, clearly-named value that cannot be confused with `loaded.aggregate.version` at the call site — the caller has to actively go out of their way to pass the wrong one, rather than naturally falling into the trap. This is the smallest correction that removes the hazard without inventing tracked aggregates, an identity map, or any Unit-of-Work behavior (all of which remain correctly excluded). See Finding M020-REVIEW-0003 (**CRITICAL**).

## H. Add Contract

Design §16 is well-specified: `add` requires non-existence, allows any valid non-negative current `AggregateVersion` (correctly respecting that process-local mutation can occur before first persistence — Master Context §7 confirms all four aggregates support pre-persistence mutation), raises `AggregateAlreadyExists` on duplicate/concurrent-race identity, forbids `exists()`-as-guarantee, and returns `SaveResult(operation=CREATED, persisted_version=aggregate.version)`. **No finding.** This section is implementation-ready as written.

## I. Save Contract

Design §17 covers: match → persist; mismatch → `OptimisticConcurrencyConflict`; current version ≥ expected (both `>` and `==` explicitly discussed). It does **not** cover two of the eight cases this mission's instructions explicitly enumerate:

1. **Durable identity is missing** (`save()` called for an identity that was never `add()`-ed). Design §17 only discusses "durable version" comparison, implicitly assuming a durable row exists. Nothing states what error is raised if it does not. The mission's own instruction is explicit: *"Save must never insert a missing identity."* Silence on what save *does* raise in this case leaves the implementer to invent it. **Finding M020-REVIEW-0004 (MAJOR).**
2. **Aggregate current version < expected persisted version** (Design §17 states current version "must be" ≥ expected, but never says what happens when this precondition is violated). This is not a normal concurrent-write race (those produce current ≥ expected, durable > expected — covered by `OptimisticConcurrencyConflict`); a current version *below* the expected persisted version indicates the in-memory aggregate itself is in an impossible state relative to the caller's own belief about durable state — most plausibly a caller/application error (e.g., passing a stale/foreign version number for a different aggregate instance), not a legitimate storage race. **Finding M020-REVIEW-0005 (MAJOR).**

Independent decision for both, detailed in the corrected design:
- **Missing durable identity on `save()`** → raise `AggregateNotFound` (the same, already-existing error used by `get()`; conceptually consistent — "there is no durable row for this identity" is the same fact whether discovered via `get()` or `save()`).
- **Current version < expected persisted version** → raise `InvalidAggregateForPersistence` (already-existing error whose stated purpose is exactly "not retryable without code/data correction" — matching a caller/programming-error case, and distinct from the legitimately-retryable `OptimisticConcurrencyConflict`).

Both corrections reuse **already-selected error types** — no new error class is introduced, keeping the taxonomy exactly as narrow as the design intended.

## J. Version Ordering

Design §15's four-term vocabulary (aggregate current version / expected persisted version / persisted version after save / new aggregate state) is precise, non-overlapping, and correctly forbids `AggregateVersion | None` overloading. **No finding** — this section is a strength of the design, not a weakness.

## K. Unchanged and Repeated Save

Design §18–19 exactly match the mission's own frozen numeric example (loaded=5, mutated to 7, save(expected=5)→persisted 7; save(expected=7)→`UNCHANGED`; save(expected=5) again→`OptimisticConcurrencyConflict`). Independently re-derived and confirmed identical. **No finding.** Note: this section's correctness *depends on* the Section G correction being adopted — without a `LoadedAggregate`-style forced separation of "persisted version" from "current version," a caller could still corrupt this exact sequence at the call site by re-reading `aggregate.version` instead of retaining the originally-returned `persisted_version`. The two findings (G and K) are related but distinct: K's *rules* are correct; G's *API shape* is what makes it easy to violate them by accident.

## L. SaveResult

Design §22's conceptual shape (`operation: CREATED|UPDATED|UNCHANGED`, `persisted_version`) is correct and appropriately minimal — no database metadata, no returned aggregate, no hidden transaction token. **The only gap is module placement** (folded into Finding M020-REVIEW-0001, Section D above) — the *shape* itself needs no correction.

## M. Error Taxonomy

Design §23's five-error hierarchy under `RepositoryContractError` is well-scoped and correctly excludes infrastructure/availability errors. Two secondary gaps, both MINOR:
- The `aggregate kind` field's exact type is never specified (string literal? enum? the aggregate class itself?). **Finding M020-REVIEW-0006 (MINOR)** — resolved in the corrected design by introducing a small `AggregateKind` enum (`CAMPAIGN`, `RUN`, `EVIDENCE_PACKAGE`, `REVIEW`), placed in the same new `shared.repository` module.
- The `retryability` value (`RETRYABLE_AFTER_RELOAD` in Design §20) is written as a bare string/label, not typed. **Finding M020-REVIEW-0007 (MINOR)** — resolved by introducing a small `Retryability` enum (`RETRYABLE_AFTER_RELOAD`, `NOT_RETRYABLE`), same module.

Also confirmed correct: `ReconstructionError → InvalidPersistedAggregateState` translation direction (Design §23, last subsection) is consistent with M019's `ReconstructionError`/`ReconstructionErrorCategory` design and does not require any change to the frozen M019 error model itself.

## N. Reconstruction Integration

Design §24's frozen load/save flow diagrams are **verified, verbatim-consistent** with M019's actual frozen reconstruction architecture (Master Context §8: `_reconstruct_*` factories, internal `_reconstruction` modules, `object.__new__` mechanism, one shared `ReconstructionError`). No repository-contract text anywhere in the design exposes a reconstruction state record, a `_reconstruct_*` factory name, or an internal module path to a public caller. **No finding.** This is the design's strongest section — it is the one place where a prior milestone (M019) is explicitly at risk of being silently reopened, and it is not.

## O. Atomicity

Design §25–26 correctly scope one-aggregate atomicity (identity, lifecycle, version, sequence, history, scalar state, owned collections, terminal metadata — matching exactly the "atomic rejection" and "reconstruction fidelity" invariants frozen across M013–M019) while correctly deferring transaction objects, Unit-of-Work public contracts, row locking, and multi-aggregate transactions. **No finding.**

## P. Contract Testing

Design §29's future test matrix is thorough for the cases the design itself defined, but necessarily inherits the two Save Contract gaps (Section I above): it does not yet list a test for "save on missing durable identity" or "current version below expected persisted version," because the design never defined the expected behavior for either. Once Findings M020-REVIEW-0004/0005 are corrected (Section I), two test cases should be added to Design §29's "Required save tests" list. This is captured as part of the corrected design rather than as a separate finding.

## Q. Implementation Readiness Matrix

| Area | Ready for implementation-scope mission without further design correction? |
| --- | --- |
| Repository architecture (aggregate-specific) | Yes |
| Contract placement — four repository interfaces | Yes |
| Contract placement — shared value/error types | **No — corrected in this review (Finding 0001)** |
| Sync/async decision | Yes |
| Identity input | Yes, with a documented assumption added (Finding 0002) |
| Load result / concurrency token | **No — corrected in this review (Finding 0003, CRITICAL)** |
| Add contract | Yes |
| Save contract — normal cases | Yes |
| Save contract — missing durable identity, current<expected | **No — corrected in this review (Findings 0004, 0005)** |
| Version vocabulary | Yes |
| Unchanged/repeated save | Yes (depends on Finding 0003 correction) |
| SaveResult shape | Yes |
| Error taxonomy — hierarchy | Yes |
| Error taxonomy — field types | Minor gaps corrected (Findings 0006, 0007) |
| Reconstruction integration | Yes |
| Atomicity / transaction boundary | Yes |
| Query/delete exclusions | Yes |

## R. Findings

| ID | Severity | Design section | Design statement | Frozen/source evidence | Finding | Impact | Required correction | Disposition |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M020-REVIEW-0001 | MAJOR | §8, §22, §23 | Design gives exact module paths for the four repository interfaces but never states a module for `SaveOperation`, `SaveResult`, `RepositoryContractError`, or its five subclasses. | M019 precedent: `ReconstructionError`/`ReconstructionErrorCategory` placed in `shared.domain.reconstruction` (Master Context §8). | Undefined module placement — an implementer would have to invent where these shared types live. | Implementer could scatter shared types across aggregate packages, or duplicate them per aggregate, contradicting the "shared, aggregate-neutral" intent of §22/§23. | Add `empirical_platform.shared.repository` as the exact module for all shared repository-contract value/error types (see corrected design §8a). | Corrected in portable candidate |
| M020-REVIEW-0002 | MAJOR | §11 | "Repository load/create/save operations use canonical `DomainIdentity[AggregateId]`." No discussion of caller feasibility. | M012 §7: identifier reservation/creation is atomic; runtime UUIDs are "never displayed as replacement governance references." | A caller holding only a governance ID (no retained runtime UUID) has no defined path to reconstruct the full `DomainIdentity` needed for `get()`. | Silent operational gap — not a defect in the frozen identity model itself, but an undocumented assumption about caller responsibility. | Add an explicit documented assumption: callers must retain the full `DomainIdentity` from creation/prior repository results; governance-ID-only resolution is explicitly out of scope and deferred. | Corrected in portable candidate (documentation only — no new mechanism invented) |
| M020-REVIEW-0003 | **CRITICAL** | §12, §17–19 | "Loaded aggregate does not carry a persistence token inside itself... the caller must supply the expected persisted version obtained from load." | Mission instruction explicitly names "implicit concurrency-token acquisition" as a blocking-finding category. | The natural, easy-to-write call pattern `save(agg, agg.version)` silently captures the **post-mutation** version instead of the version at load time, defeating optimistic concurrency without raising any error. | Silent correctness/data-integrity hazard — the exact failure mode optimistic concurrency exists to prevent. | Adopt `LoadedAggregate[AggregateT]` (mission's Option B) as the return type of `get()`, with a separately-named `.persisted_version` field distinct from `.aggregate.version`. | Corrected in portable candidate |
| M020-REVIEW-0004 | MAJOR | §17 | Save comparison assumes a durable row exists; no stated behavior when it does not. | Mission instruction: "Save must never insert a missing identity." | Undefined save-on-missing-durable-identity behavior. | Implementer must invent behavior; risk of accidental upsert-like insertion, contradicting the frozen `add`/`save` separation (§14). | Raise `AggregateNotFound` (reuse existing error) when `save()` targets an identity with no durable row. | Corrected in portable candidate |
| M020-REVIEW-0005 | MAJOR | §17 | "The current aggregate version must be greater than or equal to the expected persisted version" — no stated behavior for the violation case. | Mission instruction explicitly lists "undefined current-version-below-expected behavior" as a blocking-finding category. | Undefined behavior when aggregate current version < expected persisted version. | Implementer must invent behavior; risk of conflating a caller/programming error with a legitimate concurrency conflict. | Raise `InvalidAggregateForPersistence` (reuse existing error; its stated purpose — "not retryable without code/data correction" — matches this case) distinct from `OptimisticConcurrencyConflict`. | Corrected in portable candidate |
| M020-REVIEW-0006 | MINOR | §23 | "aggregate kind" field type unspecified across all five errors. | — | Ambiguous field type; implementer must guess string vs. enum vs. class. | Low — cosmetic/type-safety only. | Introduce `AggregateKind` enum (`CAMPAIGN`, `RUN`, `EVIDENCE_PACKAGE`, `REVIEW`) in `shared.repository`. | Corrected in portable candidate |
| M020-REVIEW-0007 | MINOR | §20, §23 | `retryability` value (`RETRYABLE_AFTER_RELOAD`) written as a bare label, not typed. | — | Ambiguous field type. | Low — cosmetic/type-safety only. | Introduce `Retryability` enum (`RETRYABLE_AFTER_RELOAD`, `NOT_RETRYABLE`) in `shared.repository`. | Corrected in portable candidate |
| OBS-01 | OBSERVATION | §6 | Option C (shared generic save/load primitives) rejected as "too framework-like" without a concrete counter-example. | — | Assertion without demonstration. | None — does not block freeze; noted for the record only. | None required; the ultimate decision (Option B) is independently confirmed correct regardless of this gap in the supporting argument. | Not corrected — non-blocking, recorded for transparency |

**CRITICAL findings: 1. MAJOR findings: 5. MINOR findings: 2. OBSERVATION: 1.**

Per `PROJECT_OPERATING_MANUAL.md` §12 (severity table), the presence of one CRITICAL and five MAJOR findings means this design, **as originally written, is not ready to freeze**. All seven blocking findings (0001–0007) are addressed by narrow, non-scope-expanding corrections in the accompanying corrected design candidate; none of them required inventing new architecture, new persistence mechanisms, or contradicting any frozen M012–M019 decision.

## S. Corrections Required

See Findings table (Section R) for the itemized list. Summarized, the corrected design candidate (`MILESTONE_020_DOMAIN_REPOSITORY_AND_CONCURRENCY_CONTRACT_DESIGN_PORTABLE_CORRECTION.md`) makes exactly these changes relative to the original:

1. Adds a module-placement subsection naming `empirical_platform.shared.repository` for all shared value/error types.
2. Adds `LoadedAggregate[AggregateT]` as the return type of `get()`, replacing the bare-aggregate return, with `.aggregate` and `.persisted_version` fields.
3. Adds an explicit documented assumption about caller identity retention (Finding 0002).
4. Adds explicit `save()`-on-missing-identity behavior (`AggregateNotFound`).
5. Adds explicit current-version-below-expected behavior (`InvalidAggregateForPersistence`).
6. Adds `AggregateKind` and `Retryability` enums to the shared module.
7. Updates the contract-testing section (§29 equivalent) to add the two now-defined save-failure test cases.
8. Updates the Hostile Self-Review and Acceptance Gate tables to reflect this second review pass.

No other content is changed. Every original design decision not listed above (aggregate-specific architecture, sync-only contracts, `add`/`save` separation, four-term version vocabulary, atomicity boundary, query/delete exclusions, reconstruction integration) is preserved **verbatim in substance**.

## T. Repository Installation Plan

See the accompanying `M020_PORTABLE_INSTALLATION_INSTRUCTIONS.md` for the exact, step-by-step procedure a future local Claude Code session (with live repository access) must follow to reconcile this portable correction against the authoritative repository. In summary: verify baseline, diff the portable correction against the live document, resolve rather than blindly overwrite, apply only to the single authoritative M020 design document, rerun full hostile review and validation, commit separately, package external review evidence, and freeze only after executable evidence — no step in that plan is performed here.

## U. Portable Limitations

- No `git rev-parse HEAD`, `git status`, or `git log` was run — the design baseline (`7d802bc57f085564f682017051f419d69552fb62`) and the operator-asserted design commit (`8dd31a6dc947048beb4fa7d273b0c3e8c31e0183`) are both **unverified** in this environment, exactly as flagged in `EMPIRICAL_TRADING_PLATFORM_MASTER_CONTEXT.md` (CONFLICT-0001) and `PROJECT_OPERATING_MANUAL.md` (MANUAL-CONFLICT-0001). This review does not resolve that discrepancy and does not treat either hash as confirmed.
- No pytest, ruff, mypy, architecture-checker, or security-scan command was executed — this review is a documentation-level reasoning exercise, not executable validation.
- No source code was written or evaluated — the review's conclusions are about the *design document's* completeness and internal consistency, not about any implementation.
- The findings above are **portable-review-grade**: they must be re-confirmed by a live, repository-connected independent review before this milestone may actually be frozen, per `PROJECT_OPERATING_MANUAL.md` §12 and §22.

## V. Final Portable Decision

```text
DESIGN CORRECTION REQUIRED — NOT READY FOR FREEZE AS ORIGINALLY WRITTEN
CORRECTED PORTABLE CANDIDATE PRODUCED
PENDING REPOSITORY INSTALLATION AND LIVE INDEPENDENT RE-REVIEW
```
